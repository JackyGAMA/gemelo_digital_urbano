/**
 * FloodMirror AI - API Client
 * Conexión con el backend FastAPI
 */

const API_BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

export interface FloodPredictionRequest {
  // CDMX specific data
  alcaldia?: string;
  intensidad?: number;
  int2?: number;
  area_m2?: number;
  period_ret?: number;
  latitud?: number;
  longitud?: number;
  
  // General flood parameters
  monsoon_intensity?: number;
  topography_drainage?: number;
  river_management?: number;
  deforestation?: number;
  urbanization?: number;
  drainage_systems?: number;
  population_score?: number;
  watersheds?: number;
}

export interface ConfidenceMetrics {
  overall_confidence: number;
  data_completeness: number;
  model_confidence: number;
  prediction_stability: number;
  model_certainty: number;
  mirror_penalty: number;
}

export interface MirrorInfo {
  activated: boolean;
  missing_fields: string[];
  imputed_fields: string[];
  imputation_method: string | null;
}

export interface Explanation {
  main_factors: string[];
  interpretation: string;
  feature_importance: Record<string, number>;
}

export interface Recommendation {
  category: string;
  priority: string;
  action: string;
  description: string;
  resources?: string[];
}

export interface FloodPredictionResponse {
  risk_level: "low" | "medium" | "high";
  flood_probability: number;
  confidence: ConfidenceMetrics;
  mirror_info: MirrorInfo;
  explanation: Explanation;
  recommendations: Recommendation[];
  location_info?: {
    alcaldia?: string;
    latitud?: number;
    longitud?: number;
    model_version?: string;
    model_accuracy?: number;
  };
}

export interface HealthResponse {
  status: string;
  version: string;
  model_loaded: boolean;
  data_loaded: boolean;
}

/**
 * Check API health
 */
export async function checkHealth(): Promise<HealthResponse> {
  const response = await fetch(`${API_BASE_URL}/health`);
  if (!response.ok) {
    throw new Error(`Health check failed: ${response.statusText}`);
  }
  return response.json();
}

/**
 * Predict flood risk using model V1 (original)
 */
export async function predictFloodRisk(
  request: FloodPredictionRequest
): Promise<FloodPredictionResponse> {
  const response = await fetch(`${API_BASE_URL}/predict`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(request),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: response.statusText }));
    throw new Error(error.detail || "Prediction failed");
  }

  return response.json();
}

/**
 * Predict flood risk using model V2 (XGBoost - higher accuracy)
 */
export async function predictFloodRiskV2(
  request: FloodPredictionRequest
): Promise<FloodPredictionResponse> {
  const response = await fetch(`${API_BASE_URL}/predict/v2`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(request),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: response.statusText }));
    throw new Error(error.detail || "Prediction V2 failed");
  }

  return response.json();
}

/**
 * Get model information
 */
export async function getModelInfo() {
  const response = await fetch(`${API_BASE_URL}/model/info`);
  if (!response.ok) {
    throw new Error(`Failed to get model info: ${response.statusText}`);
  }
  return response.json();
}

/**
 * Get model V2 information
 */
export async function getModelV2Info() {
  const response = await fetch(`${API_BASE_URL}/model/v2/info`);
  if (!response.ok) {
    throw new Error(`Failed to get model V2 info: ${response.statusText}`);
  }
  return response.json();
}

/**
 * Get data statistics
 */
export async function getDataStats() {
  const response = await fetch(`${API_BASE_URL}/data/stats`);
  if (!response.ok) {
    throw new Error(`Failed to get data stats: ${response.statusText}`);
  }
  return response.json();
}

/**
 * Get alcaldía information
 */
export async function getAlcaldiaInfo(alcaldiaName: string) {
  const response = await fetch(`${API_BASE_URL}/alcaldia/${encodeURIComponent(alcaldiaName)}`);
  if (!response.ok) {
    throw new Error(`Failed to get alcaldía info: ${response.statusText}`);
  }
  return response.json();
}

// Made with Bob
