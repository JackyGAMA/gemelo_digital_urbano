# 🚀 Guía Rápida de Inicio - FloodMirror AI

Esta guía te llevará paso a paso para probar el backend en menos de 5 minutos.

## Paso 1: Preparar el Entorno

### 1.1 Abrir Terminal
Abre una terminal en el directorio `floodmirror-ai-backend`:

```bash
cd floodmirror-ai-backend
```

### 1.2 Crear Entorno Virtual (Recomendado)

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**Linux/Mac:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### 1.3 Instalar Dependencias

```bash
pip install -r requirements.txt
```

Esto instalará: FastAPI, Uvicorn, Pandas, Scikit-learn, etc.

## Paso 2: Preparar Datos de Prueba

Tienes dos opciones:

### Opción A: Usar tus propios datos CSV
Coloca tus archivos en el directorio `data/`:
- `data/flood_clean.csv`
- `data/cdmx_clean.csv`

### Opción B: Generar datos sintéticos (Recomendado para prueba rápida)

Crea un archivo `generate_sample_data.py` en el directorio raíz:

```python
import pandas as pd
import numpy as np

# Crear directorio data si no existe
import os
os.makedirs('data', exist_ok=True)

# Generar flood_clean.csv
print("Generando flood_clean.csv...")
n_samples = 1000
flood_data = pd.DataFrame({
    'MonsoonIntensity': np.random.uniform(0, 1, n_samples),
    'TopographyDrainage': np.random.uniform(0, 1, n_samples),
    'RiverManagement': np.random.uniform(0, 1, n_samples),
    'Deforestation': np.random.uniform(0, 1, n_samples),
    'Urbanization': np.random.uniform(0, 1, n_samples),
    'DrainageSystems': np.random.uniform(0, 1, n_samples),
    'PopulationScore': np.random.uniform(0, 1, n_samples),
    'Watersheds': np.random.uniform(0, 1, n_samples),
})

# Calcular FloodProbability basado en factores
flood_data['FloodProbability'] = (
    flood_data['MonsoonIntensity'] * 0.3 +
    flood_data['Urbanization'] * 0.25 +
    (1 - flood_data['DrainageSystems']) * 0.2 +
    flood_data['Deforestation'] * 0.15 +
    (1 - flood_data['RiverManagement']) * 0.1
)

flood_data.to_csv('data/flood_clean.csv', index=False)
print(f"✅ Creado flood_clean.csv con {n_samples} registros")

# Generar cdmx_clean.csv
print("Generando cdmx_clean.csv...")
alcaldias = ['Iztapalapa', 'Tláhuac', 'Xochimilco', 'Gustavo A. Madero', 
             'Venustiano Carranza', 'Iztacalco', 'Cuauhtémoc', 'Álvaro Obregón']

cdmx_data = pd.DataFrame({
    'alcaldia': np.random.choice(alcaldias, 500),
    'intensidad': np.random.uniform(20, 80, 500),
    'int2': np.random.uniform(15, 70, 500),
    'area_m2': np.random.uniform(1000, 10000, 500),
    'period_ret': np.random.uniform(5, 50, 500),
    'latitud': np.random.uniform(19.1, 19.6, 500),
    'longitud': np.random.uniform(-99.3, -98.9, 500)
})

cdmx_data.to_csv('data/cdmx_clean.csv', index=False)
print(f"✅ Creado cdmx_clean.csv con 500 registros")
print("\n🎉 Datos de prueba generados exitosamente!")
```

Ejecuta el script:
```bash
python generate_sample_data.py
```

## Paso 3: Iniciar el Servidor

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Deberías ver algo como:
```
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
INFO:     Started reloader process
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
```

**¡El servidor está corriendo!** 🎉

## Paso 4: Probar la API

### Opción 1: Documentación Interactiva (Más Fácil)

1. Abre tu navegador
2. Ve a: `http://localhost:8000/docs`
3. Verás la interfaz Swagger UI
4. Haz clic en `POST /predict`
5. Haz clic en "Try it out"
6. Usa este ejemplo:

```json
{
  "alcaldia": "Iztapalapa",
  "intensidad": 45.5,
  "int2": 38.2,
  "area_m2": 5000.0,
  "period_ret": 10.0,
  "latitud": 19.3573,
  "longitud": -99.0699
}
```

7. Haz clic en "Execute"
8. ¡Verás la predicción completa con explicaciones y recomendaciones!

### Opción 2: Script de Prueba Automatizado

En una **nueva terminal** (mantén el servidor corriendo):

```bash
# Activar entorno virtual si es necesario
# Windows: venv\Scripts\activate
# Linux/Mac: source venv/bin/activate

python test_api.py
```

Este script probará todos los endpoints automáticamente.

### Opción 3: Usando curl (Terminal)

```bash
curl -X POST "http://localhost:8000/predict" \
  -H "Content-Type: application/json" \
  -d "{\"alcaldia\":\"Iztapalapa\",\"intensidad\":45.5,\"area_m2\":5000.0}"
```

### Opción 4: Usando Python requests

Crea un archivo `test_simple.py`:

```python
import requests
import json

# Hacer predicción
response = requests.post(
    "http://localhost:8000/predict",
    json={
        "alcaldia": "Iztapalapa",
        "intensidad": 45.5,
        "int2": 38.2,
        "area_m2": 5000.0,
        "period_ret": 10.0,
        "latitud": 19.3573,
        "longitud": -99.0699
    }
)

# Mostrar resultado
print("Status:", response.status_code)
print("\nRespuesta:")
print(json.dumps(response.json(), indent=2, ensure_ascii=False))
```

Ejecuta:
```bash
python test_simple.py
```

## Paso 5: Explorar Otros Endpoints

### Health Check
```bash
curl http://localhost:8000/health
```

O en navegador: `http://localhost:8000/health`

### Información del Modelo
```bash
curl http://localhost:8000/model/info
```

### Estadísticas de Datos
```bash
curl http://localhost:8000/data/stats
```

### Info de Alcaldía
```bash
curl http://localhost:8000/alcaldia/Iztapalapa
```

## 🧪 Casos de Prueba Interesantes

### 1. Riesgo Alto (muchos datos)
```json
{
  "alcaldia": "Iztapalapa",
  "intensidad": 75.0,
  "int2": 68.0,
  "area_m2": 8000.0,
  "period_ret": 5.0,
  "latitud": 19.3573,
  "longitud": -99.0699
}
```

### 2. Riesgo Bajo
```json
{
  "alcaldia": "Cuauhtémoc",
  "intensidad": 25.0,
  "int2": 20.0,
  "area_m2": 2000.0,
  "period_ret": 50.0
}
```

### 3. Datos Mínimos (Activar Mirror)
```json
{
  "intensidad": 50.0
}
```
Este caso activará el módulo Mirror para imputar datos faltantes.

### 4. Parámetros Generales
```json
{
  "monsoon_intensity": 0.8,
  "urbanization": 0.9,
  "drainage_systems": 0.3,
  "population_score": 0.85
}
```

## 📊 Entender la Respuesta

La API devuelve:

```json
{
  "risk_level": "high",              // Nivel de riesgo
  "flood_probability": 0.78,         // Probabilidad 0-1
  "confidence": {
    "overall_confidence": 0.85,      // Confianza general
    "data_completeness": 0.90,       // Completitud de datos
    "model_certainty": 0.88,         // Certeza del modelo
    "mirror_penalty": 0.95           // Penalización por Mirror
  },
  "mirror_info": {
    "activated": true,               // ¿Se usó Mirror?
    "missing_fields": [...],         // Campos faltantes
    "imputed_fields": [...],         // Campos imputados
    "imputation_method": "knn"       // Método usado
  },
  "explanation": {
    "main_factors": [...],           // Factores principales
    "interpretation": "...",         // Explicación en español
    "feature_importance": {...}      // Importancia de características
  },
  "recommendations": [...]           // Recomendaciones accionables
}
```

## 🐛 Solución de Problemas

### Error: "Model not loaded"
- Verifica que los archivos CSV estén en `data/`
- Revisa los logs del servidor para errores de entrenamiento

### Error: "Module not found"
- Asegúrate de haber activado el entorno virtual
- Reinstala dependencias: `pip install -r requirements.txt`

### Puerto 8000 ocupado
- Usa otro puerto: `uvicorn app.main:app --reload --port 8001`
- O detén el proceso que usa el puerto 8000

### Datos no se cargan
- Verifica nombres de archivos: `flood_clean.csv` y `cdmx_clean.csv`
- Revisa formato CSV (separador coma, encoding UTF-8)

## 🎯 Próximos Pasos

1. **Integrar con Frontend**: Usa los endpoints desde React, Vue, etc.
2. **Personalizar**: Modifica `config.py` para ajustar parámetros
3. **Mejorar Modelo**: Entrena con tus propios datos reales
4. **Desplegar**: Usa Docker, Heroku, AWS, etc.

## 📚 Recursos Adicionales

- Documentación interactiva: `http://localhost:8000/docs`
- Documentación alternativa: `http://localhost:8000/redoc`
- README completo: `README.md`
- Configuración: `config.py`

---

**¿Necesitas ayuda?** Revisa los logs del servidor o el archivo README.md para más detalles.

¡Disfruta probando FloodMirror AI! 🌊🤖