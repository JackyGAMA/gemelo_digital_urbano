"""
Script de prueba para FloodMirror AI API
Prueba los endpoints principales de la API
"""
import requests
import json
from typing import Dict, Any


class FloodMirrorAPITester:
    """Clase para probar la API de FloodMirror"""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        """
        Inicializar tester
        
        Args:
            base_url: URL base de la API
        """
        self.base_url = base_url
        self.session = requests.Session()
    
    def print_response(self, title: str, response: requests.Response):
        """Imprimir respuesta formateada"""
        print(f"\n{'='*60}")
        print(f"🧪 {title}")
        print(f"{'='*60}")
        print(f"Status Code: {response.status_code}")
        
        try:
            data = response.json()
            print(f"Response:\n{json.dumps(data, indent=2, ensure_ascii=False)}")
        except:
            print(f"Response: {response.text}")
    
    def test_health(self):
        """Probar endpoint de health check"""
        url = f"{self.base_url}/health"
        response = self.session.get(url)
        self.print_response("Health Check", response)
        return response.status_code == 200
    
    def test_root(self):
        """Probar endpoint raíz"""
        url = f"{self.base_url}/"
        response = self.session.get(url)
        self.print_response("Root Endpoint", response)
        return response.status_code == 200
    
    def test_prediction_cdmx(self):
        """Probar predicción con datos de CDMX"""
        url = f"{self.base_url}/predict"
        
        # Caso 1: Datos completos
        payload = {
            "alcaldia": "Iztapalapa",
            "intensidad": 45.5,
            "int2": 38.2,
            "area_m2": 5000.0,
            "period_ret": 10.0,
            "latitud": 19.3573,
            "longitud": -99.0699
        }
        
        response = self.session.post(url, json=payload)
        self.print_response("Predicción CDMX - Datos Completos", response)
        
        # Caso 2: Datos parciales (activar Mirror)
        payload_partial = {
            "alcaldia": "Tláhuac",
            "intensidad": 60.0,
            "area_m2": 3000.0
        }
        
        response_partial = self.session.post(url, json=payload_partial)
        self.print_response("Predicción CDMX - Datos Parciales (Mirror)", response_partial)
        
        return response.status_code == 200
    
    def test_prediction_general(self):
        """Probar predicción con parámetros generales"""
        url = f"{self.base_url}/predict"
        
        payload = {
            "monsoon_intensity": 0.8,
            "topography_drainage": 0.6,
            "river_management": 0.5,
            "deforestation": 0.7,
            "urbanization": 0.9,
            "drainage_systems": 0.4,
            "population_score": 0.8,
            "watersheds": 0.6
        }
        
        response = self.session.post(url, json=payload)
        self.print_response("Predicción General - Parámetros Completos", response)
        return response.status_code == 200
    
    def test_prediction_minimal(self):
        """Probar predicción con datos mínimos (máximo uso de Mirror)"""
        url = f"{self.base_url}/predict"
        
        payload = {
            "intensidad": 50.0
        }
        
        response = self.session.post(url, json=payload)
        self.print_response("Predicción Mínima - Máximo Mirror", response)
        return response.status_code == 200
    
    def test_model_info(self):
        """Probar endpoint de información del modelo"""
        url = f"{self.base_url}/model/info"
        response = self.session.get(url)
        self.print_response("Model Info", response)
        return response.status_code in [200, 503]  # 503 si no hay modelo
    
    def test_data_stats(self):
        """Probar endpoint de estadísticas de datos"""
        url = f"{self.base_url}/data/stats"
        response = self.session.get(url)
        self.print_response("Data Statistics", response)
        return response.status_code in [200, 404, 503]
    
    def test_alcaldia_info(self):
        """Probar endpoint de información de alcaldía"""
        url = f"{self.base_url}/alcaldia/Iztapalapa"
        response = self.session.get(url)
        self.print_response("Alcaldía Info - Iztapalapa", response)
        return response.status_code in [200, 404, 503]
    
    def run_all_tests(self):
        """Ejecutar todas las pruebas"""
        print("\n" + "="*60)
        print("🚀 INICIANDO PRUEBAS DE FLOODMIRROR AI API")
        print("="*60)
        
        tests = [
            ("Health Check", self.test_health),
            ("Root Endpoint", self.test_root),
            ("Predicción CDMX", self.test_prediction_cdmx),
            ("Predicción General", self.test_prediction_general),
            ("Predicción Mínima", self.test_prediction_minimal),
            ("Model Info", self.test_model_info),
            ("Data Stats", self.test_data_stats),
            ("Alcaldía Info", self.test_alcaldia_info)
        ]
        
        results = []
        for test_name, test_func in tests:
            try:
                success = test_func()
                results.append((test_name, "✅ PASS" if success else "❌ FAIL"))
            except Exception as e:
                results.append((test_name, f"❌ ERROR: {str(e)}"))
        
        # Resumen
        print("\n" + "="*60)
        print("📊 RESUMEN DE PRUEBAS")
        print("="*60)
        for test_name, result in results:
            print(f"{result} - {test_name}")
        
        passed = sum(1 for _, r in results if "✅" in r)
        total = len(results)
        print(f"\n✨ Pruebas exitosas: {passed}/{total}")


def main():
    """Función principal"""
    import sys
    
    # Obtener URL base de argumentos o usar default
    base_url = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000"
    
    print(f"🌐 Probando API en: {base_url}")
    print("⚠️  Asegúrate de que la API esté corriendo antes de ejecutar las pruebas")
    print("   Ejecuta: uvicorn app.main:app --reload")
    
    input("\nPresiona Enter para continuar...")
    
    tester = FloodMirrorAPITester(base_url)
    tester.run_all_tests()


if __name__ == "__main__":
    main()

# Made with Bob
