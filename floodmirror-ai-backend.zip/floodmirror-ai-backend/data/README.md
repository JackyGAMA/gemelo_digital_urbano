# Data Directory

Este directorio debe contener los archivos CSV necesarios para el funcionamiento de FloodMirror AI.

## Archivos Requeridos

### 1. flood_clean.csv
Datos históricos de inundaciones con las siguientes columnas:

- `MonsoonIntensity`: Intensidad del monzón (0-1)
- `TopographyDrainage`: Drenaje topográfico (0-1)
- `RiverManagement`: Gestión de ríos (0-1)
- `Deforestation`: Nivel de deforestación (0-1)
- `Urbanization`: Nivel de urbanización (0-1)
- `DrainageSystems`: Calidad de sistemas de drenaje (0-1)
- `PopulationScore`: Puntuación de población (0-1)
- `Watersheds`: Cuencas hidrográficas (0-1)
- `FloodProbability`: Probabilidad de inundación (0-1) - **Variable objetivo**

**Ejemplo:**
```csv
MonsoonIntensity,TopographyDrainage,RiverManagement,Deforestation,Urbanization,DrainageSystems,PopulationScore,Watersheds,FloodProbability
0.75,0.60,0.50,0.70,0.85,0.45,0.80,0.65,0.78
0.45,0.70,0.65,0.40,0.60,0.70,0.55,0.75,0.35
```

### 2. cdmx_clean.csv
Datos específicos de la Ciudad de México con las siguientes columnas:

- `alcaldia`: Nombre de la alcaldía (texto)
- `intensidad`: Intensidad de lluvia en mm/h (numérico)
- `int2`: Intensidad secundaria de lluvia (numérico)
- `area_m2`: Área en metros cuadrados (numérico)
- `period_ret`: Período de retorno en años (numérico)
- `latitud`: Latitud (decimal, -90 a 90)
- `longitud`: Longitud (decimal, -180 a 180)

**Ejemplo:**
```csv
alcaldia,intensidad,int2,area_m2,period_ret,latitud,longitud
Iztapalapa,45.5,38.2,5000.0,10.0,19.3573,-99.0699
Tláhuac,52.3,44.1,4500.0,15.0,19.2856,-99.0134
Xochimilco,38.7,32.5,6000.0,8.0,19.2577,-99.1036
```

## Formato de Datos

- **Encoding**: UTF-8
- **Separador**: Coma (,)
- **Valores faltantes**: Dejar vacío o usar NA
- **Números decimales**: Usar punto (.) como separador

## Notas Importantes

1. Los archivos CSV deben estar en este directorio para que la API funcione correctamente
2. El modelo se entrenará automáticamente con `flood_clean.csv` al iniciar
3. Los datos de `cdmx_clean.csv` se usan para mapeo de características y estadísticas
4. Asegurar que los datos estén normalizados (0-1) para mejores resultados
5. Más datos = mejores predicciones

## Generación de Datos de Ejemplo

Si no tienes datos reales, puedes generar datos sintéticos para pruebas:

```python
import pandas as pd
import numpy as np

# Generar datos de ejemplo para flood_clean.csv
n_samples = 1000
flood_data = pd.DataFrame({
    'MonsoonIntensity': np.random.uniform(0, 1, n_samples),
    'TopographyDrainage': np.random.uniform(0, 1, n_samples),
    'RiverManagement': np.random.uniform(0, 1, n_samples),
    'Deforestation': np.random.uniform(0, 1, n_samples),
    'Urbanization': np.random.uniform(0, 1, n_samples),
    'DrainageSystems': np.random.uniform(0, 1, n_samples),
    'PopulationScore': np.random.uniform(0, 1, n_samples),
    'Watersheds': np.random.uniform(0, 1, n_samples),
})

# Calcular FloodProbability basado en factores
flood_data['FloodProbability'] = (
    flood_data['MonsoonIntensity'] * 0.3 +
    flood_data['Urbanization'] * 0.25 +
    (1 - flood_data['DrainageSystems']) * 0.2 +
    flood_data['Deforestation'] * 0.15 +
    (1 - flood_data['RiverManagement']) * 0.1
)

flood_data.to_csv('flood_clean.csv', index=False)

# Generar datos de ejemplo para cdmx_clean.csv
alcaldias = ['Iztapalapa', 'Tláhuac', 'Xochimilco', 'Gustavo A. Madero', 
             'Venustiano Carranza', 'Iztacalco', 'Cuauhtémoc']

cdmx_data = pd.DataFrame({
    'alcaldia': np.random.choice(alcaldias, 500),
    'intensidad': np.random.uniform(20, 80, 500),
    'int2': np.random.uniform(15, 70, 500),
    'area_m2': np.random.uniform(1000, 10000, 500),
    'period_ret': np.random.uniform(5, 50, 500),
    'latitud': np.random.uniform(19.1, 19.6, 500),
    'longitud': np.random.uniform(-99.3, -98.9, 500)
})

cdmx_data.to_csv('cdmx_clean.csv', index=False)
```

## Privacidad y Seguridad

⚠️ **IMPORTANTE**: 
- No subir datos sensibles o privados al repositorio
- Los archivos CSV están en `.gitignore` por defecto
- Usar datos anonimizados para demos públicas
- Cumplir con regulaciones de protección de datos (GDPR, LFPDPPP, etc.)