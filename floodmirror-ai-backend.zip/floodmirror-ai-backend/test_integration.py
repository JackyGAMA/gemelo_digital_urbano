"""
Test script for FloodMirror AI V2 integration
Tests the new XGBoost model endpoint
"""
import requests
import json

BASE_URL = "http://localhost:8000"

def test_health():
    """Test health endpoint"""
    print("Testing /health endpoint...")
    response = requests.get(f"{BASE_URL}/health")
    print(f"Status: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    print()

def test_model_v2_info():
    """Test model V2 info endpoint"""
    print("Testing /model/v2/info endpoint...")
    try:
        response = requests.get(f"{BASE_URL}/model/v2/info")
        print(f"Status: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print(f"Model Type: {data.get('model_type')}")
            print(f"Accuracy R2: {data.get('accuracy_r2')}")
            print(f"Features: {len(data.get('features', []))}")
            print(f"Top 3 Important Features:")
            for feature, importance in list(data.get('feature_importance', {}).items())[:3]:
                print(f"  - {feature}: {importance:.4f}")
        else:
            print(f"Error: {response.text}")
    except Exception as e:
        print(f"Error: {e}")
    print()

def test_predict_v2():
    """Test prediction V2 endpoint"""
    print("Testing /predict/v2 endpoint...")
    
    # Test data for CDMX
    test_data = {
        "alcaldia": "Iztapalapa",
        "intensidad": 60.0,
        "period_ret": 10.0,
        "area_m2": 5000.0,
        "latitud": 19.3573,
        "longitud": -99.0699
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/predict/v2",
            json=test_data
        )
        print(f"Status: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print(f"Risk Level: {data.get('risk_level')}")
            print(f"Flood Probability: {data.get('flood_probability'):.4f}")
            print(f"Confidence: {data.get('confidence', {}).get('overall_confidence'):.4f}")
            print(f"Model Version: {data.get('location_info', {}).get('model_version')}")
            print(f"Model Accuracy: {data.get('location_info', {}).get('model_accuracy')}")
        else:
            print(f"Error: {response.text}")
    except Exception as e:
        print(f"Error: {e}")
    print()

def main():
    print("=" * 80)
    print("FLOODMIRROR AI V2 - INTEGRATION TEST")
    print("=" * 80)
    print()
    
    print("Make sure the API is running:")
    print("  cd floodmirror-ai-backend")
    print("  uvicorn app.main:app --reload")
    print()
    input("Press Enter when API is ready...")
    print()
    
    test_health()
    test_model_v2_info()
    test_predict_v2()
    
    print("=" * 80)
    print("TESTS COMPLETED")
    print("=" * 80)

if __name__ == "__main__":
    main()

# Made with Bob
