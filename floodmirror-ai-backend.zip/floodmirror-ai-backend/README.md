# FloodMirror AI Backend

Backend API para predicción de riesgo de inundación urbana en la CDMX con módulo Mirror para manejo inteligente de datos limitados.

## 🌊 Descripción

FloodMirror AI es una plataforma de inteligencia artificial diseñada para estimar el riesgo de inundación urbana cuando existen datos limitados. El sistema utiliza un módulo Mirror innovador que imputa datos faltantes de manera inteligente, permitiendo predicciones confiables incluso con información incompleta.

### Características Principales

- **Predicción de Riesgo**: Modelo de ML entrenado con datos históricos de inundaciones
- **Módulo Mirror**: Imputa datos faltantes usando múltiples estrategias (KNN, contextual, estadística)
- **Cálculo de Confianza**: Métricas detalladas de confianza de la predicción
- **Explicaciones**: Interpretaciones en español de los factores de riesgo
- **Recomendaciones**: Acciones específicas basadas en el nivel de riesgo
- **Soporte CDMX**: Integración específica para datos de alcaldías de la Ciudad de México

## 📋 Requisitos

- Python 3.8+
- pip

## 🚀 Instalación

1. **Clonar el repositorio**
```bash
git clone <repository-url>
cd floodmirror-ai-backend
```

2. **Crear entorno virtual**
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

3. **Instalar dependencias**
```bash
pip install -r requirements.txt
```

4. **Configurar variables de entorno**
```bash
cp .env.example .env
# Editar .env según sea necesario
```

5. **Preparar datos**

Crear directorio `data/` y colocar los archivos CSV:
- `flood_clean.csv`: Datos históricos de inundaciones
- `cdmx_clean.csv`: Datos específicos de CDMX

**Formato flood_clean.csv:**
```csv
MonsoonIntensity,TopographyDrainage,RiverManagement,Deforestation,Urbanization,DrainageSystems,PopulationScore,Watersheds,FloodProbability
```

**Formato cdmx_clean.csv:**
```csv
alcaldia,intensidad,int2,area_m2,period_ret,latitud,longitud
```

## 🏃 Ejecución

### Modo Desarrollo
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Modo Producción
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

La API estará disponible en: `http://localhost:8000`

Documentación interactiva: `http://localhost:8000/docs`

## 📚 Estructura del Proyecto

```
floodmirror-ai-backend/
├── app/
│   ├── __init__.py
│   ├── main.py                 # Aplicación FastAPI principal
│   ├── models/
│   │   ├── __init__.py
│   │   └── schemas.py          # Modelos Pydantic
│   ├── ml/
│   │   ├── __init__.py
│   │   ├── model.py            # Modelo de ML
│   │   └── mirror.py           # Módulo Mirror
│   ├── services/
│   │   ├── __init__.py
│   │   ├── confidence.py       # Cálculo de confianza
│   │   ├── explainer.py        # Generador de explicaciones
│   │   └── recommendations.py  # Motor de recomendaciones
│   └── utils/
│       ├── __init__.py
│       └── data_loader.py      # Carga de datos
├── data/                       # Archivos CSV (no incluidos)
├── models/                     # Modelos entrenados (generados)
├── config.py                   # Configuración
├── requirements.txt            # Dependencias
├── .env.example               # Variables de entorno ejemplo
└── README.md                  # Este archivo
```

## 🔌 API Endpoints

### Health Check
```http
GET /health
```
Verifica el estado de la API y componentes cargados.

### Predicción de Riesgo
```http
POST /predict
Content-Type: application/json

{
  "alcaldia": "Iztapalapa",
  "intensidad": 45.5,
  "int2": 38.2,
  "area_m2": 5000.0,
  "period_ret": 10.0,
  "latitud": 19.3573,
  "longitud": -99.0699
}
```

**Respuesta:**
```json
{
  "risk_level": "high",
  "flood_probability": 0.78,
  "confidence": {
    "overall_confidence": 0.85,
    "data_completeness": 0.90,
    "model_certainty": 0.88,
    "mirror_penalty": 0.95
  },
  "mirror_info": {
    "activated": true,
    "missing_fields": ["drainage_systems"],
    "imputed_fields": ["drainage_systems"],
    "imputation_method": "knn"
  },
  "explanation": {
    "main_factors": [...],
    "interpretation": "...",
    "feature_importance": {...}
  },
  "recommendations": [...]
}
```

### Información del Modelo
```http
GET /model/info
```
Retorna información sobre el modelo cargado y características.

### Estadísticas de Datos
```http
GET /data/stats
```
Retorna estadísticas de los datasets cargados.

### Información de Alcaldía
```http
GET /alcaldia/{alcaldia_name}
```
Retorna estadísticas específicas de una alcaldía.

## 🧠 Módulo Mirror

El módulo Mirror es el componente innovador que permite predicciones confiables con datos incompletos:

### Estrategias de Imputación

1. **Contextual**: Usa relaciones entre características relacionadas
2. **KNN**: Imputa basándose en casos similares históricos
3. **Estadística**: Usa mediana/media de datos históricos
4. **Auto**: Selecciona automáticamente la mejor estrategia

### Cálculo de Confianza

El sistema calcula confianza basándose en:
- **Completitud de datos** (35%): Proporción de datos proporcionados
- **Certeza del modelo** (40%): Confianza de la predicción del ML
- **Penalización Mirror** (25%): Impacto de datos imputados

## 🎯 Niveles de Riesgo

- **Muy Bajo** (0-20%): Condiciones favorables
- **Bajo** (20-40%): Riesgo limitado
- **Moderado** (40-60%): Requiere atención
- **Alto** (60-80%): Acción preventiva necesaria
- **Muy Alto** (80-100%): Acción inmediata requerida

## 🔧 Configuración Avanzada

Editar `config.py` para ajustar:
- Parámetros del modelo ML
- Pesos de confianza
- Umbrales de riesgo
- Configuración de Mirror

## 📊 Entrenamiento del Modelo

El modelo se entrena automáticamente al iniciar si no existe uno guardado. Para reentrenar:

1. Eliminar archivos en `models/`
2. Reiniciar la aplicación
3. El modelo se entrenará con los datos en `data/`

## 🐛 Troubleshooting

### Error: "Model not loaded"
- Verificar que existan los archivos CSV en `data/`
- Revisar formato de los CSV
- Verificar logs para errores de entrenamiento

### Error: "Data files not found"
- Asegurar que `flood_clean.csv` y `cdmx_clean.csv` estén en `data/`
- Verificar nombres de archivos en `config.py`

### Baja confianza en predicciones
- Proporcionar más datos de entrada
- Verificar calidad de datos históricos
- Ajustar pesos de confianza en `config.py`

## 🧪 Testing

Para probar la API:

```bash
# Usando curl
curl -X POST "http://localhost:8000/predict" \
  -H "Content-Type: application/json" \
  -d '{
    "alcaldia": "Iztapalapa",
    "intensidad": 45.5,
    "area_m2": 5000.0
  }'

# O visitar la documentación interactiva
# http://localhost:8000/docs
```

## 📝 Notas para Hackathon

- **Demo-ready**: El código está optimizado para demostración
- **Modular**: Fácil de extender y modificar
- **Documentado**: Comentarios en español para claridad
- **GitHub-ready**: Estructura profesional para repositorio

## 🤝 Contribuciones

Este proyecto fue desarrollado para un hackathon. Para contribuir:

1. Fork el repositorio
2. Crear branch de feature
3. Commit cambios
4. Push al branch
5. Crear Pull Request

## 📄 Licencia

[Especificar licencia]

## 👥 Autores

[Especificar autores del equipo]

## 🙏 Agradecimientos

- Datos de inundaciones históricas
- Comunidad de FastAPI
- Scikit-learn

---

**FloodMirror AI** - Predicción inteligente de riesgo de inundación con datos limitados 🌊🤖