"""
FASE 2: LIMPIEZA PROFESIONAL DE DATOS
FloodMirror AI - Integración de Datos Oficiales CDMX

Este script limpia y estandariza todos los datasets identificados en la auditoria.
"""

import pandas as pd
import geopandas as gpd
import numpy as np
from pathlib import Path
import warnings
import sys
import io

# Configurar encoding para Windows
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
warnings.filterwarnings('ignore')

# Configuración
DATA_DIR = Path("data")
OUTPUT_DIR = DATA_DIR / "cleaned"
OUTPUT_DIR.mkdir(exist_ok=True)

print("=" * 80)
print("FASE 2: LIMPIEZA PROFESIONAL DE DATOS - FLOODMIRROR AI")
print("=" * 80)
print()

# =============================================================================
# 1. ATLAS DE RIESGO DE PRECIPITACIÓN CDMX
# =============================================================================
print("=" * 80)
print("LIMPIANDO: Atlas de Riesgo de Precipitación CDMX")
print("=" * 80)

try:
    atlas_path = DATA_DIR / "Atlas_de_Riesgo_de_Precipitacion_CDMX.csv"
    df_atlas = pd.read_csv(atlas_path)
    
    print(f"📊 Registros originales: {len(df_atlas):,}")
    
    # Eliminar duplicados si existen
    df_atlas_clean = df_atlas.drop_duplicates()
    print(f"✅ Duplicados eliminados: {len(df_atlas) - len(df_atlas_clean):,}")
    
    # Verificar y limpiar valores nulos
    nulls_before = df_atlas_clean.isnull().sum().sum()
    df_atlas_clean = df_atlas_clean.dropna()
    nulls_removed = nulls_before - df_atlas_clean.isnull().sum().sum()
    print(f"✅ Valores nulos eliminados: {nulls_removed:,}")
    
    # Guardar
    output_path = OUTPUT_DIR / "atlas_precipitacion_clean.csv"
    df_atlas_clean.to_csv(output_path, index=False)
    print(f"💾 Guardado: {output_path}")
    print(f"📊 Registros finales: {len(df_atlas_clean):,}")
    print()
    
except Exception as e:
    print(f"❌ Error: {e}")
    print()

# =============================================================================
# 2. SITIOS RECURRENTES DE ENCHARCAMIENTO
# =============================================================================
print("=" * 80)
print("LIMPIANDO: Sitios Recurrentes de Encharcamiento")
print("=" * 80)

try:
    encharcamiento_path = DATA_DIR / "Sitios_recurrentes_de_encharcamiento.shp"
    gdf_encharcamiento = gpd.read_file(encharcamiento_path)
    
    print(f"📊 Registros originales: {len(gdf_encharcamiento):,}")
    print(f"🗺️  CRS original: {gdf_encharcamiento.crs}")
    
    # Transformar a EPSG:4326 (WGS84)
    if gdf_encharcamiento.crs != "EPSG:4326":
        gdf_encharcamiento = gdf_encharcamiento.to_crs("EPSG:4326")
        print(f"✅ CRS transformado a: EPSG:4326")
    
    # Validar geometrías
    invalid_geoms = ~gdf_encharcamiento.is_valid
    if invalid_geoms.any():
        print(f"⚠️  Geometrías inválidas encontradas: {invalid_geoms.sum()}")
        gdf_encharcamiento.loc[invalid_geoms, 'geometry'] = gdf_encharcamiento.loc[invalid_geoms, 'geometry'].buffer(0)
        print(f"✅ Geometrías corregidas")
    
    # Eliminar duplicados
    gdf_encharcamiento_clean = gdf_encharcamiento.drop_duplicates()
    print(f"✅ Duplicados eliminados: {len(gdf_encharcamiento) - len(gdf_encharcamiento_clean):,}")
    
    # Guardar
    output_path = OUTPUT_DIR / "encharcamiento_clean.geojson"
    gdf_encharcamiento_clean.to_file(output_path, driver='GeoJSON')
    print(f"💾 Guardado: {output_path}")
    print(f"📊 Registros finales: {len(gdf_encharcamiento_clean):,}")
    print()
    
except Exception as e:
    print(f"❌ Error: {e}")
    print()

# =============================================================================
# 3. CARACTERÍSTICAS DE VIVIENDAS POR AGEB
# =============================================================================
print("=" * 80)
print("LIMPIANDO: Características de Viviendas por AGEB")
print("=" * 80)

try:
    viviendas_path = DATA_DIR / "Caracteristicas_de_viviendas_por_AGEB.shp"
    gdf_viviendas = gpd.read_file(viviendas_path)
    
    print(f"📊 Registros originales: {len(gdf_viviendas):,}")
    print(f"🗺️  CRS: {gdf_viviendas.crs}")
    
    # Limpiar nombres de columnas (convertir a string y limpiar)
    gdf_viviendas.columns = [str(col).strip().replace(' ', '_') for col in gdf_viviendas.columns]
    print(f"✅ Nombres de columnas normalizados")
    
    # Convertir columnas numéricas que puedan estar como string
    for col in gdf_viviendas.columns:
        if col != 'geometry':
            try:
                # Intentar convertir a numérico si es posible
                gdf_viviendas[col] = pd.to_numeric(gdf_viviendas[col], errors='ignore')
            except:
                pass
    
    # Validar geometrías
    invalid_geoms = ~gdf_viviendas.is_valid
    if invalid_geoms.any():
        print(f"⚠️  Geometrías inválidas encontradas: {invalid_geoms.sum()}")
        gdf_viviendas.loc[invalid_geoms, 'geometry'] = gdf_viviendas.loc[invalid_geoms, 'geometry'].buffer(0)
        print(f"✅ Geometrías corregidas")
    
    # Eliminar duplicados
    gdf_viviendas_clean = gdf_viviendas.drop_duplicates()
    print(f"✅ Duplicados eliminados: {len(gdf_viviendas) - len(gdf_viviendas_clean):,}")
    
    # Guardar
    output_path = OUTPUT_DIR / "viviendas_ageb_clean.geojson"
    gdf_viviendas_clean.to_file(output_path, driver='GeoJSON')
    print(f"💾 Guardado: {output_path}")
    print(f"📊 Registros finales: {len(gdf_viviendas_clean):,}")
    print()
    
except Exception as e:
    print(f"❌ Error: {e}")
    print()

# =============================================================================
# 4. CDMX CLEAN (DATASET EXISTENTE)
# =============================================================================
print("=" * 80)
print("LIMPIANDO: CDMX Clean (Dataset Existente)")
print("=" * 80)

try:
    cdmx_path = DATA_DIR / "flood_clean.csv"
    df_cdmx = pd.read_csv(cdmx_path)
    
    print(f"📊 Registros originales: {len(df_cdmx):,}")
    
    # Eliminar duplicados (problema identificado en auditoría)
    df_cdmx_clean = df_cdmx.drop_duplicates()
    duplicates_removed = len(df_cdmx) - len(df_cdmx_clean)
    print(f"✅ Duplicados eliminados: {duplicates_removed:,}")
    
    # Verificar valores nulos
    nulls = df_cdmx_clean.isnull().sum()
    if nulls.any():
        print(f"⚠️  Valores nulos por columna:")
        for col, count in nulls[nulls > 0].items():
            print(f"   - {col}: {count}")
        df_cdmx_clean = df_cdmx_clean.dropna()
        print(f"✅ Registros con nulos eliminados")
    
    # Guardar
    output_path = OUTPUT_DIR / "cdmx_clean_deduplicated.csv"
    df_cdmx_clean.to_csv(output_path, index=False)
    print(f"💾 Guardado: {output_path}")
    print(f"📊 Registros finales: {len(df_cdmx_clean):,}")
    print()
    
except Exception as e:
    print(f"❌ Error: {e}")
    print()

# =============================================================================
# RESUMEN FINAL
# =============================================================================
print("=" * 80)
print("✅ LIMPIEZA COMPLETADA")
print("=" * 80)
print(f"📁 Datos limpios guardados en: {OUTPUT_DIR}")
print()
print("Archivos generados:")
print("  1. atlas_precipitacion_clean.csv")
print("  2. encharcamiento_clean.geojson")
print("  3. viviendas_ageb_clean.geojson")
print("  4. cdmx_clean_deduplicated.csv")
print()
print("Próximo paso: FASE 3 - Ingeniería de Características")
print("=" * 80)

# Made with Bob
