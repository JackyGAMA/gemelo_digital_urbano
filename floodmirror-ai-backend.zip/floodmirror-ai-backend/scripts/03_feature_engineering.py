"""
FASE 3: INGENIERIA DE CARACTERISTICAS
FloodMirror AI - Integracion de Datos Oficiales CDMX

Este script extrae y crea caracteristicas relevantes para el modelo predictivo.
"""

import pandas as pd
import geopandas as gpd
import numpy as np
from pathlib import Path
import json
import warnings
import sys
import io

# Configurar encoding para Windows
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
warnings.filterwarnings('ignore')

# Configuracion
DATA_DIR = Path("data/cleaned")
OUTPUT_DIR = Path("data/features")
OUTPUT_DIR.mkdir(exist_ok=True)

print("=" * 80)
print("FASE 3: INGENIERIA DE CARACTERISTICAS - FLOODMIRROR AI")
print("=" * 80)
print()

# =============================================================================
# 1. CARGAR DATOS LIMPIOS
# =============================================================================
print("Cargando datos limpios...")

# Atlas de Precipitacion
df_atlas = pd.read_csv(DATA_DIR / "atlas_precipitacion_clean.csv")
print(f"OK: Atlas de Precipitacion - {len(df_atlas):,} registros")

# Sitios de Encharcamiento
gdf_encharcamiento = gpd.read_file(DATA_DIR / "encharcamiento_clean.geojson")
print(f"OK: Sitios de Encharcamiento - {len(gdf_encharcamiento):,} registros")

# Viviendas por AGEB
gdf_viviendas = gpd.read_file(DATA_DIR / "viviendas_ageb_clean.geojson")
print(f"OK: Viviendas por AGEB - {len(gdf_viviendas):,} registros")

print()

# =============================================================================
# 2. EXTRAER COORDENADAS DEL ATLAS
# =============================================================================
print("=" * 80)
print("EXTRAYENDO COORDENADAS Y GEOMETRIAS")
print("=" * 80)

# Extraer latitud y longitud del campo geo_point_2d
df_atlas[['latitud', 'longitud']] = df_atlas['geo_point_2d'].str.split(',', expand=True).astype(float)

# Parsear geometrias del campo geo_shape (JSON)
def parse_geometry(geo_shape_str):
    try:
        geom_dict = json.loads(geo_shape_str)
        return geom_dict
    except:
        return None

df_atlas['geometry_dict'] = df_atlas['geo_shape'].apply(parse_geometry)

# Crear GeoDataFrame
from shapely.geometry import shape
df_atlas['geometry'] = df_atlas['geometry_dict'].apply(lambda x: shape(x) if x else None)
gdf_atlas = gpd.GeoDataFrame(df_atlas, geometry='geometry', crs="EPSG:4326")

print(f"OK: Coordenadas extraidas - {len(gdf_atlas):,} registros")
print()

# =============================================================================
# 3. CARACTERISTICAS DE PRECIPITACION
# =============================================================================
print("=" * 80)
print("CREANDO CARACTERISTICAS DE PRECIPITACION")
print("=" * 80)

# Mapeo de intensidad a valores numericos
intensidad_map = {
    'Muy bajo': 1,
    'Bajo': 2,
    'Medio': 3,
    'Alto': 4,
    'Muy alto': 5
}

gdf_atlas['intensidad_nivel'] = gdf_atlas['r_p_v_e'].map(intensidad_map).fillna(2)

# Extraer periodo de retorno (años)
gdf_atlas['periodo_retorno_num'] = gdf_atlas['period_ret'].str.extract(r'(\d+)').astype(float)

# Usar int2 que ya es numerico (1-5)
gdf_atlas['int2'] = pd.to_numeric(gdf_atlas['int2'], errors='coerce')

# Normalizar intensidad numerica (int2 va de 1 a 5)
gdf_atlas['intensidad_normalizada'] = (gdf_atlas['int2'] - 1) / 4  # Normalizar a 0-1

# Calcular area en km2
gdf_atlas['area_km2'] = gdf_atlas['area_m2'] / 1_000_000

# Crear score de riesgo de precipitacion
gdf_atlas['riesgo_precipitacion'] = (
    gdf_atlas['intensidad_nivel'] * 0.4 +
    (gdf_atlas['intensidad_normalizada'] * 5) * 0.3 +
    (1 / gdf_atlas['periodo_retorno_num']) * 100 * 0.3
)

# Normalizar score de riesgo
gdf_atlas['riesgo_precipitacion'] = (
    (gdf_atlas['riesgo_precipitacion'] - gdf_atlas['riesgo_precipitacion'].min()) /
    (gdf_atlas['riesgo_precipitacion'].max() - gdf_atlas['riesgo_precipitacion'].min())
)

print(f"OK: Caracteristicas de precipitacion creadas")
print(f"   - intensidad_nivel (1-5)")
print(f"   - periodo_retorno_num (años)")
print(f"   - intensidad_normalizada (0-1)")
print(f"   - area_km2")
print(f"   - riesgo_precipitacion (0-1)")
print()

# =============================================================================
# 4. CARACTERISTICAS DE ENCHARCAMIENTO
# =============================================================================
print("=" * 80)
print("CREANDO CARACTERISTICAS DE ENCHARCAMIENTO")
print("=" * 80)

# Calcular area de cada sitio de encharcamiento
gdf_encharcamiento['area_encharcamiento_m2'] = gdf_encharcamiento.geometry.area

# Crear buffer de 500m alrededor de cada sitio
gdf_encharcamiento['buffer_500m'] = gdf_encharcamiento.geometry.buffer(0.005)  # ~500m en grados

print(f"OK: Caracteristicas de encharcamiento creadas")
print(f"   - area_encharcamiento_m2")
print(f"   - buffer_500m (zona de influencia)")
print()

# =============================================================================
# 5. INTEGRACION ESPACIAL - CONTAR SITIOS DE ENCHARCAMIENTO CERCANOS
# =============================================================================
print("=" * 80)
print("INTEGRACION ESPACIAL: ENCHARCAMIENTO")
print("=" * 80)

# Para cada punto del atlas, contar cuantos sitios de encharcamiento estan cerca
def count_nearby_flood_sites(point, flood_buffers):
    count = 0
    for buffer in flood_buffers:
        if point.within(buffer):
            count += 1
    return count

# Crear geometrias de punto para el atlas
gdf_atlas['point_geom'] = gdf_atlas.apply(
    lambda row: gpd.points_from_xy([row['longitud']], [row['latitud']])[0], 
    axis=1
)

# Contar sitios cercanos
flood_buffers = gdf_encharcamiento['buffer_500m'].tolist()
gdf_atlas['sitios_encharcamiento_cercanos'] = gdf_atlas['point_geom'].apply(
    lambda p: count_nearby_flood_sites(p, flood_buffers)
)

# Crear indicador binario
gdf_atlas['tiene_encharcamiento_cercano'] = (gdf_atlas['sitios_encharcamiento_cercanos'] > 0).astype(int)

print(f"OK: Integracion espacial completada")
print(f"   - sitios_encharcamiento_cercanos (conteo)")
print(f"   - tiene_encharcamiento_cercano (0/1)")
print()

# =============================================================================
# 6. CARACTERISTICAS DEMOGRAFICAS (VIVIENDAS)
# =============================================================================
print("=" * 80)
print("INTEGRACION ESPACIAL: VIVIENDAS")
print("=" * 80)

# Realizar spatial join para obtener caracteristicas de viviendas
gdf_atlas_with_viviendas = gpd.sjoin(
    gdf_atlas[['point_geom', 'latitud', 'longitud', 'alcaldia']].set_geometry('point_geom'),
    gdf_viviendas,
    how='left',
    predicate='within'
)

# Obtener columnas numericas disponibles (excluyendo geometry y coordenadas)
numeric_cols = gdf_atlas_with_viviendas.select_dtypes(include=[np.number]).columns.tolist()
exclude_cols = ['latitud', 'longitud', 'index_right']
available_cols = [col for col in numeric_cols if col not in exclude_cols]

# Si hay columnas disponibles, agrupar y calcular promedios
if available_cols:
    agg_dict = {col: 'mean' for col in available_cols[:10]}  # Tomar max 10 columnas
    viviendas_features = gdf_atlas_with_viviendas.groupby(['latitud', 'longitud']).agg(agg_dict).reset_index()
    
    # Merge con el atlas original
    gdf_atlas = gdf_atlas.merge(
        viviendas_features,
        on=['latitud', 'longitud'],
        how='left'
    )
    
    # Rellenar valores nulos con 0
    for col in available_cols[:10]:
        if col in gdf_atlas.columns:
            gdf_atlas[col] = gdf_atlas[col].fillna(0)
    
    # Crear densidad poblacional usando la primera columna numerica como proxy de poblacion
    if len(available_cols) > 0:
        pop_col = available_cols[0]
        gdf_atlas['densidad_poblacional'] = gdf_atlas[pop_col] / (gdf_atlas['area_km2'] + 0.001)
    else:
        gdf_atlas['densidad_poblacional'] = 0
    
    print(f"OK: Caracteristicas demograficas integradas")
    print(f"   Columnas disponibles: {', '.join(available_cols[:10])}")
    print(f"   - densidad_poblacional")
else:
    # Si no hay columnas, crear columna de densidad con 0
    gdf_atlas['densidad_poblacional'] = 0
    print(f"AVISO: No se encontraron columnas demograficas en el dataset de viviendas")
    print(f"   - densidad_poblacional establecida en 0")
print()

# =============================================================================
# 7. CREAR VARIABLE OBJETIVO: RIESGO DE INUNDACION
# =============================================================================
print("=" * 80)
print("CREANDO VARIABLE OBJETIVO")
print("=" * 80)

# Combinar multiples factores para crear el riesgo de inundacion
gdf_atlas['FloodProbability'] = (
    gdf_atlas['riesgo_precipitacion'] * 0.40 +
    (gdf_atlas['sitios_encharcamiento_cercanos'] / (gdf_atlas['sitios_encharcamiento_cercanos'].max() + 1)) * 0.30 +
    (gdf_atlas['densidad_poblacional'] / (gdf_atlas['densidad_poblacional'].max() + 1)) * 0.20 +
    (gdf_atlas['area_km2'] / (gdf_atlas['area_km2'].max() + 1)) * 0.10
)

# Normalizar a 0-1
gdf_atlas['FloodProbability'] = (
    (gdf_atlas['FloodProbability'] - gdf_atlas['FloodProbability'].min()) /
    (gdf_atlas['FloodProbability'].max() - gdf_atlas['FloodProbability'].min())
)

# Crear categorias de riesgo
gdf_atlas['RiskCategory'] = pd.cut(
    gdf_atlas['FloodProbability'],
    bins=[0, 0.2, 0.4, 0.6, 0.8, 1.0],
    labels=['Muy Bajo', 'Bajo', 'Medio', 'Alto', 'Muy Alto']
)

print(f"OK: Variable objetivo creada")
print(f"   - FloodProbability (0-1)")
print(f"   - RiskCategory (Muy Bajo a Muy Alto)")
print()

# =============================================================================
# 8. SELECCIONAR Y GUARDAR CARACTERISTICAS FINALES
# =============================================================================
print("=" * 80)
print("GUARDANDO DATASET FINAL")
print("=" * 80)

# Seleccionar columnas relevantes para el modelo
base_columns = [
    # Identificadores
    'id', 'alcaldia', 'latitud', 'longitud',
    
    # Caracteristicas de precipitacion
    'intensidad_nivel', 'periodo_retorno_num', 'intensidad_normalizada',
    'area_km2', 'riesgo_precipitacion',
    
    # Caracteristicas de encharcamiento
    'sitios_encharcamiento_cercanos', 'tiene_encharcamiento_cercano',
    
    # Caracteristicas demograficas
    'densidad_poblacional',
    
    # Variable objetivo
    'FloodProbability', 'RiskCategory'
]

# Agregar columnas demograficas disponibles
demographic_cols_available = [col for col in gdf_atlas.columns if col in available_cols[:10]] if 'available_cols' in locals() else []
feature_columns = base_columns + demographic_cols_available

# Filtrar columnas que existen
existing_columns = [col for col in feature_columns if col in gdf_atlas.columns]
df_final = gdf_atlas[existing_columns].copy()

# Guardar dataset final
output_path = OUTPUT_DIR / "flood_features_cdmx.csv"
df_final.to_csv(output_path, index=False)

print(f"OK: Dataset final guardado")
print(f"   Archivo: {output_path}")
print(f"   Registros: {len(df_final):,}")
print(f"   Caracteristicas: {len(existing_columns)}")
print()

# Estadisticas del dataset
print("ESTADISTICAS DEL DATASET:")
print(f"   Riesgo promedio: {df_final['FloodProbability'].mean():.3f}")
print(f"   Riesgo minimo: {df_final['FloodProbability'].min():.3f}")
print(f"   Riesgo maximo: {df_final['FloodProbability'].max():.3f}")
print()
print("Distribucion por categoria de riesgo:")
print(df_final['RiskCategory'].value_counts().sort_index())
print()

# =============================================================================
# 9. CREAR DATASET SIMPLIFICADO PARA EL MODELO
# =============================================================================
print("=" * 80)
print("CREANDO DATASET SIMPLIFICADO PARA MODELO")
print("=" * 80)

# Seleccionar solo caracteristicas numericas para el modelo
base_model_features = [
    'intensidad_nivel',
    'periodo_retorno_num',
    'intensidad_normalizada',
    'area_km2',
    'sitios_encharcamiento_cercanos',
    'tiene_encharcamiento_cercano',
    'densidad_poblacional',
    'FloodProbability'
]

# Agregar columnas demograficas si existen
model_features = [col for col in base_model_features if col in df_final.columns]

# Agregar primeras 3 columnas demograficas disponibles si existen
if demographic_cols_available:
    for col in demographic_cols_available[:3]:
        if col in df_final.columns and col not in model_features:
            model_features.insert(-1, col)  # Insertar antes de FloodProbability

df_model = df_final[model_features].copy()

# Eliminar filas con valores nulos
df_model = df_model.dropna()

# Guardar dataset para modelo
model_output_path = OUTPUT_DIR / "flood_model_ready.csv"
df_model.to_csv(model_output_path, index=False)

print(f"OK: Dataset para modelo guardado")
print(f"   Archivo: {model_output_path}")
print(f"   Registros: {len(df_model):,}")
print(f"   Caracteristicas: {len(model_features) - 1} (+ 1 objetivo)")
print()

print("=" * 80)
print("FASE 3 COMPLETADA")
print("=" * 80)
print(f"Archivos generados:")
print(f"  1. {output_path}")
print(f"  2. {model_output_path}")
print()
print("Proximo paso: FASE 4 - Modelado Predictivo")
print("=" * 80)

# Made with Bob
