"""
FASE 1: AUDITORÍA DE DATOS - FloodMirror AI
============================================
Script para analizar datasets oficiales de CDMX y generar reporte de calidad.

Datasets a analizar:
1. Atlas de Riesgo de Precipitación CDMX (CSV)
2. Sitios recurrentes de encharcamiento (Shapefile)
3. Características de viviendas por AGEB (Shapefile)
4. CDMX clean (CSV existente)

Autor: Data Science Team
Fecha: 2026-06-06
"""

import pandas as pd
import geopandas as gpd
import numpy as np
from pathlib import Path
import json
from datetime import datetime
import warnings
import sys
import io

# Fix encoding for Windows console
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
warnings.filterwarnings('ignore')

# Configuración de rutas
DATASETS_DIR = Path(r"C:\Users\jacqu\Downloads\datassets")
OUTPUT_DIR = Path("floodmirror-ai-backend/data/audit_reports")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

class DataAuditor:
    """Clase para auditar datasets geoespaciales y tabulares"""
    
    def __init__(self):
        self.audit_results = {}
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
    def audit_csv(self, filepath: Path, dataset_name: str) -> dict:
        """Auditar archivo CSV"""
        print(f"\n{'='*80}")
        print(f"AUDITANDO: {dataset_name}")
        print(f"{'='*80}")
        
        try:
            # Leer CSV
            df = pd.read_csv(filepath, encoding='utf-8')
            
            audit = {
                'dataset_name': dataset_name,
                'filepath': str(filepath),
                'format': 'CSV',
                'timestamp': self.timestamp,
                'rows': len(df),
                'columns': len(df.columns),
                'column_names': list(df.columns),
                'dtypes': df.dtypes.astype(str).to_dict(),
                'memory_usage_mb': df.memory_usage(deep=True).sum() / 1024**2,
                'missing_values': {},
                'duplicates': int(df.duplicated().sum()),
                'numeric_stats': {},
                'categorical_stats': {},
                'issues': []
            }
            
            # Análisis de valores nulos
            for col in df.columns:
                null_count = df[col].isnull().sum()
                null_pct = (null_count / len(df)) * 100
                audit['missing_values'][col] = {
                    'count': int(null_count),
                    'percentage': round(null_pct, 2)
                }
                if null_pct > 50:
                    audit['issues'].append(f"Columna '{col}' tiene {null_pct:.1f}% valores nulos")
            
            # Estadísticas numéricas
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            for col in numeric_cols:
                audit['numeric_stats'][col] = {
                    'mean': float(df[col].mean()) if not df[col].isnull().all() else None,
                    'median': float(df[col].median()) if not df[col].isnull().all() else None,
                    'std': float(df[col].std()) if not df[col].isnull().all() else None,
                    'min': float(df[col].min()) if not df[col].isnull().all() else None,
                    'max': float(df[col].max()) if not df[col].isnull().all() else None,
                    'q25': float(df[col].quantile(0.25)) if not df[col].isnull().all() else None,
                    'q75': float(df[col].quantile(0.75)) if not df[col].isnull().all() else None,
                    'unique_values': int(df[col].nunique())
                }
            
            # Estadísticas categóricas
            categorical_cols = df.select_dtypes(include=['object']).columns
            for col in categorical_cols:
                value_counts = df[col].value_counts()
                audit['categorical_stats'][col] = {
                    'unique_values': int(df[col].nunique()),
                    'most_common': value_counts.head(5).to_dict() if len(value_counts) > 0 else {},
                    'encoding_issues': self._check_encoding_issues(df[col])
                }
            
            # Detectar problemas
            if audit['duplicates'] > 0:
                audit['issues'].append(f"Se encontraron {audit['duplicates']} registros duplicados")
            
            # Mostrar resumen
            self._print_audit_summary(audit)
            
            return audit
            
        except Exception as e:
            print(f"❌ Error al auditar {dataset_name}: {str(e)}")
            return {'error': str(e), 'dataset_name': dataset_name}
    
    def audit_shapefile(self, filepath: Path, dataset_name: str) -> dict:
        """Auditar archivo Shapefile"""
        print(f"\n{'='*80}")
        print(f"AUDITANDO: {dataset_name}")
        print(f"{'='*80}")
        
        try:
            # Leer Shapefile
            gdf = gpd.read_file(filepath)
            
            audit = {
                'dataset_name': dataset_name,
                'filepath': str(filepath),
                'format': 'Shapefile',
                'timestamp': self.timestamp,
                'rows': len(gdf),
                'columns': len(gdf.columns),
                'column_names': list(gdf.columns),
                'dtypes': gdf.dtypes.astype(str).to_dict(),
                'crs': str(gdf.crs) if gdf.crs else 'NO CRS DEFINED',
                'geometry_type': gdf.geometry.geom_type.unique().tolist(),
                'bounds': gdf.total_bounds.tolist() if not gdf.empty else None,
                'memory_usage_mb': gdf.memory_usage(deep=True).sum() / 1024**2,
                'missing_values': {},
                'duplicates': int(gdf.duplicated().sum()),
                'geometry_issues': {},
                'numeric_stats': {},
                'categorical_stats': {},
                'issues': []
            }
            
            # Validar CRS
            if not gdf.crs:
                audit['issues'].append("⚠️ NO SE DEFINIÓ CRS - Debe asignarse manualmente")
            elif gdf.crs.to_epsg() != 4326:
                audit['issues'].append(f"CRS actual: {gdf.crs.to_epsg()} - Se recomienda transformar a EPSG:4326 (WGS84)")
            
            # Validar geometrías
            invalid_geoms = ~gdf.geometry.is_valid
            null_geoms = gdf.geometry.isnull()
            empty_geoms = gdf.geometry.is_empty
            
            audit['geometry_issues'] = {
                'invalid_count': int(invalid_geoms.sum()),
                'null_count': int(null_geoms.sum()),
                'empty_count': int(empty_geoms.sum())
            }
            
            if invalid_geoms.sum() > 0:
                audit['issues'].append(f"⚠️ {invalid_geoms.sum()} geometrías inválidas detectadas")
            if null_geoms.sum() > 0:
                audit['issues'].append(f"⚠️ {null_geoms.sum()} geometrías nulas detectadas")
            if empty_geoms.sum() > 0:
                audit['issues'].append(f"⚠️ {empty_geoms.sum()} geometrías vacías detectadas")
            
            # Análisis de valores nulos (excluyendo geometry)
            for col in gdf.columns:
                if col != 'geometry':
                    null_count = gdf[col].isnull().sum()
                    null_pct = (null_count / len(gdf)) * 100
                    audit['missing_values'][col] = {
                        'count': int(null_count),
                        'percentage': round(null_pct, 2)
                    }
                    if null_pct > 50:
                        audit['issues'].append(f"Columna '{col}' tiene {null_pct:.1f}% valores nulos")
            
            # Estadísticas numéricas
            numeric_cols = gdf.select_dtypes(include=[np.number]).columns
            for col in numeric_cols:
                audit['numeric_stats'][col] = {
                    'mean': float(gdf[col].mean()) if not gdf[col].isnull().all() else None,
                    'median': float(gdf[col].median()) if not gdf[col].isnull().all() else None,
                    'std': float(gdf[col].std()) if not gdf[col].isnull().all() else None,
                    'min': float(gdf[col].min()) if not gdf[col].isnull().all() else None,
                    'max': float(gdf[col].max()) if not gdf[col].isnull().all() else None,
                    'unique_values': int(gdf[col].nunique())
                }
            
            # Estadísticas categóricas
            categorical_cols = gdf.select_dtypes(include=['object']).columns
            for col in categorical_cols:
                if col != 'geometry':
                    value_counts = gdf[col].value_counts()
                    audit['categorical_stats'][col] = {
                        'unique_values': int(gdf[col].nunique()),
                        'most_common': value_counts.head(5).to_dict() if len(value_counts) > 0 else {},
                        'encoding_issues': self._check_encoding_issues(gdf[col])
                    }
            
            # Detectar duplicados
            if audit['duplicates'] > 0:
                audit['issues'].append(f"Se encontraron {audit['duplicates']} registros duplicados")
            
            # Mostrar resumen
            self._print_audit_summary(audit)
            
            return audit
            
        except Exception as e:
            print(f"❌ Error al auditar {dataset_name}: {str(e)}")
            return {'error': str(e), 'dataset_name': dataset_name}
    
    def _check_encoding_issues(self, series: pd.Series) -> bool:
        """Detectar problemas de codificación en texto"""
        if series.dtype != 'object':
            return False
        
        sample = series.dropna().head(100)
        for val in sample:
            if isinstance(val, str):
                # Buscar caracteres problemáticos
                if '¦' in val or '�' in val or '\x00' in val:
                    return True
        return False
    
    def _print_audit_summary(self, audit: dict):
        """Imprimir resumen de auditoría"""
        print(f"\n📊 RESUMEN DE AUDITORÍA")
        print(f"   Dataset: {audit['dataset_name']}")
        print(f"   Formato: {audit['format']}")
        print(f"   Registros: {audit['rows']:,}")
        print(f"   Columnas: {audit['columns']}")
        print(f"   Memoria: {audit['memory_usage_mb']:.2f} MB")
        
        if audit['format'] == 'Shapefile':
            print(f"   CRS: {audit['crs']}")
            print(f"   Tipo geometría: {', '.join(audit['geometry_type'])}")
        
        print(f"\n🔍 PROBLEMAS DETECTADOS: {len(audit['issues'])}")
        for issue in audit['issues']:
            print(f"   • {issue}")
        
        if not audit['issues']:
            print("   ✅ No se detectaron problemas críticos")
    
    def generate_report(self):
        """Generar reporte consolidado"""
        report_path = OUTPUT_DIR / f"data_audit_report_{self.timestamp}.json"
        
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(self.audit_results, f, indent=2, ensure_ascii=False)
        
        print(f"\n{'='*80}")
        print(f"✅ REPORTE GENERADO: {report_path}")
        print(f"{'='*80}")
        
        # Generar resumen ejecutivo
        self._generate_executive_summary()
    
    def _generate_executive_summary(self):
        """Generar resumen ejecutivo en texto"""
        summary_path = OUTPUT_DIR / f"executive_summary_{self.timestamp}.txt"
        
        with open(summary_path, 'w', encoding='utf-8') as f:
            f.write("="*80 + "\n")
            f.write("RESUMEN EJECUTIVO - AUDITORÍA DE DATOS FLOODMIRROR AI\n")
            f.write("="*80 + "\n\n")
            f.write(f"Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            total_issues = 0
            for dataset_name, audit in self.audit_results.items():
                if 'error' not in audit:
                    f.write(f"\n{dataset_name}\n")
                    f.write("-" * len(dataset_name) + "\n")
                    f.write(f"Registros: {audit['rows']:,}\n")
                    f.write(f"Columnas: {audit['columns']}\n")
                    f.write(f"Problemas: {len(audit['issues'])}\n")
                    total_issues += len(audit['issues'])
                    
                    if audit['issues']:
                        for issue in audit['issues']:
                            f.write(f"  • {issue}\n")
            
            f.write(f"\n{'='*80}\n")
            f.write(f"TOTAL DE PROBLEMAS DETECTADOS: {total_issues}\n")
            f.write(f"{'='*80}\n")
        
        print(f"📄 Resumen ejecutivo: {summary_path}")


def main():
    """Función principal"""
    print("\n" + "="*80)
    print("FASE 1: AUDITORÍA DE DATOS - FLOODMIRROR AI")
    print("="*80)
    
    auditor = DataAuditor()
    
    # 1. Atlas de Riesgo de Precipitación
    precipitacion_path = DATASETS_DIR / "atlas-de-riesgo-precipitacion.csv"
    if precipitacion_path.exists():
        audit = auditor.audit_csv(precipitacion_path, "Atlas de Riesgo de Precipitación CDMX")
        auditor.audit_results['precipitacion'] = audit
    else:
        print(f"❌ No se encontró: {precipitacion_path}")
    
    # 2. Sitios recurrentes de encharcamiento
    encharcamiento_path = DATASETS_DIR / "sitios-recurrentes-de-encharcamiento-en-ciudad-de-mexico (1)" / "Sitios recurrentes de encharcamiento en Ciudad de Me¦üxico" / "sitios_mayor_recurrencia_encharcamientos.shp"
    if encharcamiento_path.exists():
        audit = auditor.audit_shapefile(encharcamiento_path, "Sitios Recurrentes de Encharcamiento")
        auditor.audit_results['encharcamiento'] = audit
    else:
        print(f"❌ No se encontró: {encharcamiento_path}")
    
    # 3. Características de viviendas por AGEB
    viviendas_path = DATASETS_DIR / "c_viviendas_ageb_v2" / "c_viviendas_ageb.shp"
    if viviendas_path.exists():
        audit = auditor.audit_shapefile(viviendas_path, "Características de Viviendas por AGEB")
        auditor.audit_results['viviendas_ageb'] = audit
    else:
        print(f"❌ No se encontró: {viviendas_path}")
    
    # 4. CDMX clean (existente)
    cdmx_path = DATASETS_DIR / "cdmx_clean.csv"
    if cdmx_path.exists():
        audit = auditor.audit_csv(cdmx_path, "CDMX Clean (Existente)")
        auditor.audit_results['cdmx_clean'] = audit
    else:
        print(f"❌ No se encontró: {cdmx_path}")
    
    # Generar reportes
    auditor.generate_report()
    
    print("\n✅ AUDITORÍA COMPLETADA")
    print(f"📁 Reportes guardados en: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()

# Made with Bob
