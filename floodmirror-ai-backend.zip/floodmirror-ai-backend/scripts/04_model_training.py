"""
FASE 4: MODELADO PREDICTIVO
FloodMirror AI - Integracion de Datos Oficiales CDMX

Este script entrena y compara multiples modelos de ML para prediccion de riesgo de inundacion.
"""

import pandas as pd
import numpy as np
from pathlib import Path
import joblib
import json
import warnings
import sys
import io

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import xgboost as xgb
import lightgbm as lgb

# Configurar encoding para Windows
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
warnings.filterwarnings('ignore')

# Configuracion
DATA_DIR = Path("data/features")
OUTPUT_DIR = Path("models")
OUTPUT_DIR.mkdir(exist_ok=True)

print("=" * 80)
print("FASE 4: MODELADO PREDICTIVO - FLOODMIRROR AI")
print("=" * 80)
print()

# =============================================================================
# 1. CARGAR DATOS
# =============================================================================
print("Cargando datos...")
df = pd.read_csv(DATA_DIR / "flood_model_ready.csv")
print(f"OK: Dataset cargado - {len(df):,} registros")
print()

# =============================================================================
# 2. PREPARAR DATOS
# =============================================================================
print("=" * 80)
print("PREPARANDO DATOS PARA ENTRENAMIENTO")
print("=" * 80)

# Separar caracteristicas y variable objetivo
X = df.drop('FloodProbability', axis=1)
y = df['FloodProbability']

# Split train/test
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print(f"Conjunto de entrenamiento: {len(X_train):,} registros")
print(f"Conjunto de prueba: {len(X_test):,} registros")
print(f"Caracteristicas: {X.shape[1]}")
print(f"Nombres de caracteristicas: {list(X.columns)}")
print()

# =============================================================================
# 3. ENTRENAR RANDOM FOREST
# =============================================================================
print("=" * 80)
print("MODELO 1: RANDOM FOREST")
print("=" * 80)

rf_model = RandomForestRegressor(
    n_estimators=100,
    max_depth=15,
    min_samples_split=10,
    min_samples_leaf=5,
    random_state=42,
    n_jobs=-1
)

print("Entrenando Random Forest...")
rf_model.fit(X_train, y_train)

# Predicciones
rf_train_pred = rf_model.predict(X_train)
rf_test_pred = rf_model.predict(X_test)

# Metricas
rf_train_r2 = r2_score(y_train, rf_train_pred)
rf_test_r2 = r2_score(y_test, rf_test_pred)
rf_train_rmse = np.sqrt(mean_squared_error(y_train, rf_train_pred))
rf_test_rmse = np.sqrt(mean_squared_error(y_test, rf_test_pred))
rf_train_mae = mean_absolute_error(y_train, rf_train_pred)
rf_test_mae = mean_absolute_error(y_test, rf_test_pred)

print(f"OK: Random Forest entrenado")
print(f"   Train R2: {rf_train_r2:.4f}")
print(f"   Test R2: {rf_test_r2:.4f}")
print(f"   Train RMSE: {rf_train_rmse:.4f}")
print(f"   Test RMSE: {rf_test_rmse:.4f}")
print(f"   Train MAE: {rf_train_mae:.4f}")
print(f"   Test MAE: {rf_test_mae:.4f}")
print()

# Feature importance
rf_feature_importance = pd.DataFrame({
    'feature': X.columns,
    'importance': rf_model.feature_importances_
}).sort_values('importance', ascending=False)

print("Top 5 caracteristicas mas importantes:")
for idx, row in rf_feature_importance.head().iterrows():
    print(f"   {row['feature']}: {row['importance']:.4f}")
print()

# =============================================================================
# 4. ENTRENAR XGBOOST
# =============================================================================
print("=" * 80)
print("MODELO 2: XGBOOST")
print("=" * 80)

xgb_model = xgb.XGBRegressor(
    n_estimators=100,
    max_depth=6,
    learning_rate=0.1,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42,
    n_jobs=-1
)

print("Entrenando XGBoost...")
xgb_model.fit(X_train, y_train)

# Predicciones
xgb_train_pred = xgb_model.predict(X_train)
xgb_test_pred = xgb_model.predict(X_test)

# Metricas
xgb_train_r2 = r2_score(y_train, xgb_train_pred)
xgb_test_r2 = r2_score(y_test, xgb_test_pred)
xgb_train_rmse = np.sqrt(mean_squared_error(y_train, xgb_train_pred))
xgb_test_rmse = np.sqrt(mean_squared_error(y_test, xgb_test_pred))
xgb_train_mae = mean_absolute_error(y_train, xgb_train_pred)
xgb_test_mae = mean_absolute_error(y_test, xgb_test_pred)

print(f"OK: XGBoost entrenado")
print(f"   Train R2: {xgb_train_r2:.4f}")
print(f"   Test R2: {xgb_test_r2:.4f}")
print(f"   Train RMSE: {xgb_train_rmse:.4f}")
print(f"   Test RMSE: {xgb_test_rmse:.4f}")
print(f"   Train MAE: {xgb_train_mae:.4f}")
print(f"   Test MAE: {xgb_test_mae:.4f}")
print()

# =============================================================================
# 5. ENTRENAR LIGHTGBM
# =============================================================================
print("=" * 80)
print("MODELO 3: LIGHTGBM")
print("=" * 80)

lgb_model = lgb.LGBMRegressor(
    n_estimators=100,
    max_depth=6,
    learning_rate=0.1,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42,
    n_jobs=-1,
    verbose=-1
)

print("Entrenando LightGBM...")
lgb_model.fit(X_train, y_train)

# Predicciones
lgb_train_pred = lgb_model.predict(X_train)
lgb_test_pred = lgb_model.predict(X_test)

# Metricas
lgb_train_r2 = r2_score(y_train, lgb_train_pred)
lgb_test_r2 = r2_score(y_test, lgb_test_pred)
lgb_train_rmse = np.sqrt(mean_squared_error(y_train, lgb_train_pred))
lgb_test_rmse = np.sqrt(mean_squared_error(y_test, lgb_test_pred))
lgb_train_mae = mean_absolute_error(y_train, lgb_train_pred)
lgb_test_mae = mean_absolute_error(y_test, lgb_test_pred)

print(f"OK: LightGBM entrenado")
print(f"   Train R2: {lgb_train_r2:.4f}")
print(f"   Test R2: {lgb_test_r2:.4f}")
print(f"   Train RMSE: {lgb_train_rmse:.4f}")
print(f"   Test RMSE: {lgb_test_rmse:.4f}")
print(f"   Train MAE: {lgb_train_mae:.4f}")
print(f"   Test MAE: {lgb_test_mae:.4f}")
print()

# =============================================================================
# 6. COMPARAR MODELOS
# =============================================================================
print("=" * 80)
print("COMPARACION DE MODELOS")
print("=" * 80)

results = pd.DataFrame({
    'Model': ['Random Forest', 'XGBoost', 'LightGBM'],
    'Train_R2': [rf_train_r2, xgb_train_r2, lgb_train_r2],
    'Test_R2': [rf_test_r2, xgb_test_r2, lgb_test_r2],
    'Train_RMSE': [rf_train_rmse, xgb_train_rmse, lgb_train_rmse],
    'Test_RMSE': [rf_test_rmse, xgb_test_rmse, lgb_test_rmse],
    'Train_MAE': [rf_train_mae, xgb_train_mae, lgb_train_mae],
    'Test_MAE': [rf_test_mae, xgb_test_mae, lgb_test_mae]
})

print(results.to_string(index=False))
print()

# Seleccionar mejor modelo basado en Test R2
best_model_idx = results['Test_R2'].idxmax()
best_model_name = results.loc[best_model_idx, 'Model']
best_model_r2 = results.loc[best_model_idx, 'Test_R2']

print(f"MEJOR MODELO: {best_model_name}")
print(f"Test R2: {best_model_r2:.4f}")
print()

# Seleccionar el modelo ganador
if best_model_name == 'Random Forest':
    best_model = rf_model
elif best_model_name == 'XGBoost':
    best_model = xgb_model
else:
    best_model = lgb_model

# =============================================================================
# 7. GUARDAR MODELOS Y RESULTADOS
# =============================================================================
print("=" * 80)
print("GUARDANDO MODELOS Y RESULTADOS")
print("=" * 80)

# Guardar todos los modelos
joblib.dump(rf_model, OUTPUT_DIR / "random_forest_model.pkl")
print(f"OK: Random Forest guardado")

joblib.dump(xgb_model, OUTPUT_DIR / "xgboost_model.pkl")
print(f"OK: XGBoost guardado")

joblib.dump(lgb_model, OUTPUT_DIR / "lightgbm_model.pkl")
print(f"OK: LightGBM guardado")

# Guardar mejor modelo
joblib.dump(best_model, OUTPUT_DIR / "best_model.pkl")
print(f"OK: Mejor modelo ({best_model_name}) guardado")
print()

# Guardar resultados de comparacion
results.to_csv(OUTPUT_DIR / "model_comparison.csv", index=False)
print(f"OK: Comparacion de modelos guardada")

# Guardar feature importance del mejor modelo
if best_model_name == 'Random Forest':
    feature_importance = rf_feature_importance
else:
    feature_importance = pd.DataFrame({
        'feature': X.columns,
        'importance': best_model.feature_importances_
    }).sort_values('importance', ascending=False)

feature_importance.to_csv(OUTPUT_DIR / "feature_importance.csv", index=False)
print(f"OK: Feature importance guardado")
print()

# Guardar metadata
metadata = {
    'best_model': best_model_name,
    'test_r2': float(best_model_r2),
    'n_features': int(X.shape[1]),
    'n_train_samples': int(len(X_train)),
    'n_test_samples': int(len(X_test)),
    'features': list(X.columns),
    'training_date': pd.Timestamp.now().isoformat()
}

with open(OUTPUT_DIR / "model_metadata.json", 'w') as f:
    json.dump(metadata, f, indent=2)

print(f"OK: Metadata guardado")
print()

print("=" * 80)
print("FASE 4 COMPLETADA")
print("=" * 80)
print(f"Archivos generados en: {OUTPUT_DIR}")
print(f"  1. random_forest_model.pkl")
print(f"  2. xgboost_model.pkl")
print(f"  3. lightgbm_model.pkl")
print(f"  4. best_model.pkl ({best_model_name})")
print(f"  5. model_comparison.csv")
print(f"  6. feature_importance.csv")
print(f"  7. model_metadata.json")
print()
print("Proximo paso: FASE 5 - Explicabilidad (SHAP)")
print("=" * 80)

# Made with Bob
