"""
FASE 0: COPIAR DATASETS OFICIALES
FloodMirror AI - Integración de Datos Oficiales CDMX

Este script copia los datasets oficiales desde Downloads al directorio del proyecto.
"""

import shutil
from pathlib import Path

print("=" * 80)
print("COPIANDO DATASETS OFICIALES AL PROYECTO")
print("=" * 80)
print()

# Directorios
SOURCE_DIR = Path(r"C:\Users\jacqu\Downloads\datassets")
TARGET_DIR = Path("data")
TARGET_DIR.mkdir(exist_ok=True)

# Lista de archivos a copiar
files_to_copy = [
    {
        "source": SOURCE_DIR / "atlas-de-riesgo-precipitacion.csv",
        "target": TARGET_DIR / "Atlas_de_Riesgo_de_Precipitacion_CDMX.csv",
        "name": "Atlas de Riesgo de Precipitación CDMX"
    },
    {
        "source": SOURCE_DIR / "cdmx_clean.csv",
        "target": TARGET_DIR / "cdmx_clean_original.csv",
        "name": "CDMX Clean (Original)"
    }
]

# Shapefiles a copiar (copiar todos los archivos relacionados)
shapefiles = [
    {
        "source_dir": SOURCE_DIR / r"sitios-recurrentes-de-encharcamiento-en-ciudad-de-mexico (1)\Sitios recurrentes de encharcamiento en Ciudad de México",
        "source_name": "sitios_mayor_recurrencia_encharcamientos",
        "target_name": "Sitios_recurrentes_de_encharcamiento",
        "name": "Sitios Recurrentes de Encharcamiento"
    },
    {
        "source_dir": SOURCE_DIR / r"c_viviendas_ageb_v2",
        "source_name": "c_viviendas_ageb",
        "target_name": "Caracteristicas_de_viviendas_por_AGEB",
        "name": "Características de Viviendas por AGEB"
    }
]

# Copiar archivos CSV
print("Copiando archivos CSV...")
for file_info in files_to_copy:
    try:
        if file_info["source"].exists():
            shutil.copy2(file_info["source"], file_info["target"])
            print(f"OK: {file_info['name']}")
            print(f"   -> {file_info['target']}")
        else:
            print(f"ERROR: No se encontro {file_info['name']}")
            print(f"   Buscado en: {file_info['source']}")
    except Exception as e:
        print(f"ERROR al copiar {file_info['name']}: {e}")
    print()

# Copiar Shapefiles (todos los archivos relacionados)
print("Copiando Shapefiles...")
shapefile_extensions = ['.shp', '.shx', '.dbf', '.prj', '.cpg', '.sbn', '.sbx']

for shapefile_info in shapefiles:
    try:
        source_dir = shapefile_info["source_dir"]
        source_name = shapefile_info["source_name"]
        target_name = shapefile_info["target_name"]
        
        if source_dir.exists():
            copied_files = []
            for ext in shapefile_extensions:
                source_file = source_dir / f"{source_name}{ext}"
                if source_file.exists():
                    target_file = TARGET_DIR / f"{target_name}{ext}"
                    shutil.copy2(source_file, target_file)
                    copied_files.append(ext)
            
            if copied_files:
                print(f"OK: {shapefile_info['name']}")
                print(f"   Archivos copiados: {', '.join(copied_files)}")
                print(f"   -> {TARGET_DIR / target_name}.shp")
            else:
                print(f"ERROR: No se encontraron archivos para {shapefile_info['name']}")
        else:
            print(f"ERROR: Directorio no encontrado para {shapefile_info['name']}")
            print(f"   Buscado en: {source_dir}")
    except Exception as e:
        print(f"ERROR al copiar {shapefile_info['name']}: {e}")
    print()

print("=" * 80)
print("COPIA COMPLETADA")
print("=" * 80)
print(f"Archivos copiados a: {TARGET_DIR.absolute()}")
print()
print("Proximo paso: Ejecutar auditoria de datos")
print("  python scripts/01_data_audit.py")
print("=" * 80)

# Made with Bob
