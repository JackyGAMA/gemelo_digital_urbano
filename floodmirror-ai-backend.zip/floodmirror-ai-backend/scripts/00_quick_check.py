"""
Script de verificación rápida de datasets
Verifica que todos los archivos existen y son accesibles
"""

from pathlib import Path
import sys
import io

# Fix encoding for Windows console
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

DATASETS_DIR = Path(r"C:\Users\jacqu\Downloads\datassets")

def check_file(filepath: Path, description: str) -> bool:
    """Verificar si un archivo existe"""
    if filepath.exists():
        size_mb = filepath.stat().st_size / (1024 * 1024)
        print(f"[OK] {description}")
        print(f"   Ruta: {filepath}")
        print(f"   Tamaño: {size_mb:.2f} MB\n")
        return True
    else:
        print(f"[ERROR] {description}")
        print(f"   Ruta: {filepath}")
        print(f"   ERROR: Archivo no encontrado\n")
        return False

def main():
    print("="*80)
    print("VERIFICACIÓN RÁPIDA DE DATASETS")
    print("="*80 + "\n")
    
    all_ok = True
    
    # 1. Atlas de Precipitación
    precipitacion = DATASETS_DIR / "atlas-de-riesgo-precipitacion.csv"
    all_ok &= check_file(precipitacion, "Atlas de Riesgo de Precipitación CDMX")
    
    # 2. Sitios de Encharcamiento
    encharcamiento = DATASETS_DIR / "sitios-recurrentes-de-encharcamiento-en-ciudad-de-mexico (1)" / "Sitios recurrentes de encharcamiento en Ciudad de Me¦üxico" / "sitios_mayor_recurrencia_encharcamientos.shp"
    all_ok &= check_file(encharcamiento, "Sitios Recurrentes de Encharcamiento")
    
    # 3. Viviendas AGEB
    viviendas = DATASETS_DIR / "c_viviendas_ageb_v2" / "c_viviendas_ageb.shp"
    all_ok &= check_file(viviendas, "Características de Viviendas por AGEB")
    
    # 4. CDMX Clean
    cdmx = DATASETS_DIR / "cdmx_clean.csv"
    all_ok &= check_file(cdmx, "CDMX Clean (Existente)")
    
    print("="*80)
    if all_ok:
        print("[OK] TODOS LOS DATASETS ESTAN DISPONIBLES")
        print("="*80)
        return 0
    else:
        print("[ERROR] ALGUNOS DATASETS NO ESTAN DISPONIBLES")
        print("="*80)
        return 1

if __name__ == "__main__":
    sys.exit(main())

# Made with Bob
