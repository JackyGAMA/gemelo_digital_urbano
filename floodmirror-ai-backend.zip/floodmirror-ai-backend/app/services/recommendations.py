"""
Recommendations engine for FloodMirror AI
Generates actionable recommendations based on flood risk predictions
"""
from typing import List, Dict, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class RecommendationEngine:
    """
    Generates context-aware recommendations for flood risk mitigation
    """
    
    def __init__(self):
        """Initialize recommendation engine"""
        # Recommendation templates by risk level
        self.recommendations_by_risk = {
            'very_high': [
                {
                    'priority': 'high',
                    'category': 'emergency',
                    'action': 'Activar sistema de alerta temprana inmediatamente',
                    'rationale': 'Probabilidad de inundación crítica (>80%)'
                },
                {
                    'priority': 'high',
                    'category': 'emergency',
                    'action': 'Evacuar áreas de alto riesgo y zonas bajas',
                    'rationale': 'Riesgo inminente para la población'
                },
                {
                    'priority': 'high',
                    'category': 'infrastructure',
                    'action': 'Cerrar accesos a zonas inundables',
                    'rationale': 'Prevenir accidentes y facilitar operaciones de emergencia'
                },
                {
                    'priority': 'high',
                    'category': 'monitoring',
                    'action': 'Monitoreo continuo de niveles de agua cada 15 minutos',
                    'rationale': 'Situación crítica requiere vigilancia constante'
                }
            ],
            'high': [
                {
                    'priority': 'high',
                    'category': 'emergency',
                    'action': 'Preparar equipos de respuesta de emergencia',
                    'rationale': 'Alta probabilidad de inundación (60-80%)'
                },
                {
                    'priority': 'high',
                    'category': 'infrastructure',
                    'action': 'Verificar funcionamiento de sistemas de drenaje',
                    'rationale': 'Asegurar capacidad máxima de desalojo de agua'
                },
                {
                    'priority': 'medium',
                    'category': 'monitoring',
                    'action': 'Aumentar frecuencia de monitoreo a cada 30 minutos',
                    'rationale': 'Situación puede deteriorarse rápidamente'
                },
                {
                    'priority': 'medium',
                    'category': 'emergency',
                    'action': 'Alertar a población en zonas de riesgo',
                    'rationale': 'Preparación preventiva de la comunidad'
                }
            ],
            'moderate': [
                {
                    'priority': 'medium',
                    'category': 'monitoring',
                    'action': 'Monitoreo regular cada hora',
                    'rationale': 'Riesgo moderado (40-60%) requiere vigilancia'
                },
                {
                    'priority': 'medium',
                    'category': 'infrastructure',
                    'action': 'Inspeccionar sistemas de drenaje preventivamente',
                    'rationale': 'Identificar y resolver obstrucciones'
                },
                {
                    'priority': 'low',
                    'category': 'emergency',
                    'action': 'Mantener equipos de emergencia en estado de alerta',
                    'rationale': 'Preparación para posible escalamiento'
                },
                {
                    'priority': 'low',
                    'category': 'infrastructure',
                    'action': 'Revisar planes de contingencia',
                    'rationale': 'Asegurar preparación operativa'
                }
            ],
            'low': [
                {
                    'priority': 'low',
                    'category': 'monitoring',
                    'action': 'Monitoreo rutinario cada 3 horas',
                    'rationale': 'Mantener vigilancia básica'
                },
                {
                    'priority': 'low',
                    'category': 'infrastructure',
                    'action': 'Mantenimiento preventivo de infraestructura',
                    'rationale': 'Aprovechar condiciones favorables para mejoras'
                },
                {
                    'priority': 'low',
                    'category': 'monitoring',
                    'action': 'Actualizar mapas de riesgo',
                    'rationale': 'Mejorar preparación para futuros eventos'
                }
            ],
            'very_low': [
                {
                    'priority': 'low',
                    'category': 'monitoring',
                    'action': 'Monitoreo estándar diario',
                    'rationale': 'Condiciones favorables, vigilancia rutinaria'
                },
                {
                    'priority': 'low',
                    'category': 'infrastructure',
                    'action': 'Realizar mantenimiento programado',
                    'rationale': 'Momento óptimo para trabajos de infraestructura'
                },
                {
                    'priority': 'low',
                    'category': 'emergency',
                    'action': 'Capacitación de personal de emergencia',
                    'rationale': 'Aprovechar período de calma para entrenamiento'
                }
            ]
        }
        
        # Feature-specific recommendations
        self.feature_recommendations = {
            'MonsoonIntensity': {
                'high': {
                    'action': 'Preparar bombas de agua adicionales',
                    'rationale': 'Alta intensidad de lluvia requiere mayor capacidad de desalojo'
                },
                'low': {
                    'action': 'Mantenimiento de sistemas de captación',
                    'rationale': 'Aprovechar baja intensidad para mejoras'
                }
            },
            'DrainageSystems': {
                'poor': {
                    'action': 'Limpieza urgente de sistemas de drenaje',
                    'rationale': 'Drenaje deficiente aumenta significativamente el riesgo'
                },
                'good': {
                    'action': 'Continuar programa de mantenimiento',
                    'rationale': 'Mantener eficiencia de sistemas'
                }
            },
            'Urbanization': {
                'high': {
                    'action': 'Implementar soluciones de drenaje urbano sostenible',
                    'rationale': 'Alta urbanización reduce absorción natural'
                }
            },
            'PopulationScore': {
                'high': {
                    'action': 'Reforzar planes de evacuación masiva',
                    'rationale': 'Alta densidad poblacional requiere mayor coordinación'
                }
            }
        }
    
    def generate_recommendations(
        self,
        risk_level: str,
        flood_probability: float,
        feature_contributions: Dict[str, float],
        confidence: float,
        alcaldia: Optional[str] = None
    ) -> List[Dict[str, str]]:
        """
        Generate comprehensive recommendations
        
        Args:
            risk_level: Predicted risk level
            flood_probability: Flood probability (0-1)
            feature_contributions: Feature importance scores
            confidence: Prediction confidence
            alcaldia: Alcaldía name (optional)
            
        Returns:
            List of recommendation dictionaries
        """
        recommendations = []
        
        # Get base recommendations for risk level
        base_recs = self.recommendations_by_risk.get(risk_level, [])
        recommendations.extend(base_recs)
        
        # Add feature-specific recommendations
        feature_recs = self._get_feature_specific_recommendations(
            feature_contributions, flood_probability
        )
        recommendations.extend(feature_recs)
        
        # Add confidence-based recommendations
        if confidence < 0.7:
            recommendations.append({
                'priority': 'medium',
                'category': 'monitoring',
                'action': 'Recopilar datos adicionales para mejorar precisión',
                'rationale': f'Confianza de predicción limitada ({confidence*100:.0f}%)'
            })
        
        # Add location-specific recommendations
        if alcaldia:
            location_recs = self._get_location_recommendations(alcaldia, risk_level)
            recommendations.extend(location_recs)
        
        # Sort by priority
        priority_order = {'high': 0, 'medium': 1, 'low': 2}
        recommendations.sort(key=lambda x: priority_order.get(x['priority'], 3))
        
        logger.info(f"Generated {len(recommendations)} recommendations for {risk_level} risk")
        
        return recommendations
    
    def _get_feature_specific_recommendations(
        self,
        feature_contributions: Dict[str, float],
        flood_probability: float
    ) -> List[Dict[str, str]]:
        """
        Generate recommendations based on specific features
        
        Args:
            feature_contributions: Feature importance scores
            flood_probability: Flood probability
            
        Returns:
            List of feature-specific recommendations
        """
        recommendations = []
        
        # Check top contributing features
        sorted_features = sorted(
            feature_contributions.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        for feature, contribution in sorted_features[:2]:  # Top 2 features
            if contribution > 0.25:  # Significant contribution
                if 'Drainage' in feature and contribution > 0.3:
                    recommendations.append({
                        'priority': 'high',
                        'category': 'infrastructure',
                        'action': 'Inspección urgente de sistemas de drenaje',
                        'rationale': f'Drenaje es factor crítico ({contribution*100:.0f}% de influencia)'
                    })
                elif 'Intensity' in feature or 'intensidad' in feature:
                    recommendations.append({
                        'priority': 'high',
                        'category': 'monitoring',
                        'action': 'Monitoreo intensivo de precipitación',
                        'rationale': f'Intensidad de lluvia es factor dominante ({contribution*100:.0f}%)'
                    })
                elif 'Urbanization' in feature or 'area' in feature:
                    recommendations.append({
                        'priority': 'medium',
                        'category': 'infrastructure',
                        'action': 'Evaluar capacidad de absorción en zonas urbanas',
                        'rationale': f'Urbanización contribuye significativamente ({contribution*100:.0f}%)'
                    })
        
        return recommendations
    
    def _get_location_recommendations(
        self,
        alcaldia: str,
        risk_level: str
    ) -> List[Dict[str, str]]:
        """
        Generate location-specific recommendations
        
        Args:
            alcaldia: Alcaldía name
            risk_level: Risk level
            
        Returns:
            List of location-specific recommendations
        """
        recommendations = []
        
        # Known high-risk alcaldías in CDMX
        high_risk_alcaldias = ['Iztapalapa', 'Tláhuac', 'Xochimilco']
        
        if alcaldia in high_risk_alcaldias and risk_level in ['high', 'very_high']:
            recommendations.append({
                'priority': 'high',
                'category': 'emergency',
                'action': f'Activar protocolo específico para {alcaldia}',
                'rationale': f'{alcaldia} es zona históricamente vulnerable a inundaciones'
            })
        
        # Add general location recommendation
        if risk_level in ['high', 'very_high']:
            recommendations.append({
                'priority': 'medium',
                'category': 'emergency',
                'action': f'Coordinar con autoridades locales de {alcaldia}',
                'rationale': 'Respuesta coordinada mejora efectividad'
            })
        
        return recommendations
    
    def get_immediate_actions(
        self,
        risk_level: str,
        flood_probability: float
    ) -> List[str]:
        """
        Get list of immediate actions required
        
        Args:
            risk_level: Risk level
            flood_probability: Flood probability
            
        Returns:
            List of immediate action strings
        """
        immediate_actions = []
        
        if risk_level == 'very_high':
            immediate_actions = [
                'Activar alerta roja',
                'Iniciar evacuación de zonas críticas',
                'Desplegar equipos de emergencia',
                'Cerrar accesos a zonas de riesgo'
            ]
        elif risk_level == 'high':
            immediate_actions = [
                'Activar alerta naranja',
                'Preparar equipos de respuesta',
                'Alertar a población en riesgo',
                'Verificar sistemas de drenaje'
            ]
        elif risk_level == 'moderate':
            immediate_actions = [
                'Activar alerta amarilla',
                'Aumentar frecuencia de monitoreo',
                'Revisar planes de contingencia',
                'Inspeccionar infraestructura crítica'
            ]
        else:
            immediate_actions = [
                'Mantener monitoreo rutinario',
                'Continuar mantenimiento preventivo'
            ]
        
        return immediate_actions
    
    def get_long_term_recommendations(
        self,
        risk_level: str,
        feature_contributions: Dict[str, float]
    ) -> List[Dict[str, str]]:
        """
        Generate long-term mitigation recommendations
        
        Args:
            risk_level: Risk level
            feature_contributions: Feature importance scores
            
        Returns:
            List of long-term recommendations
        """
        long_term = []
        
        # Infrastructure improvements
        if risk_level in ['high', 'very_high', 'moderate']:
            long_term.append({
                'priority': 'high',
                'category': 'infrastructure',
                'action': 'Desarrollar plan de mejora de infraestructura de drenaje',
                'rationale': 'Reducir vulnerabilidad estructural a largo plazo'
            })
        
        # Urban planning
        if 'Urbanization' in feature_contributions and feature_contributions['Urbanization'] > 0.2:
            long_term.append({
                'priority': 'medium',
                'category': 'infrastructure',
                'action': 'Implementar estrategias de urbanización sostenible',
                'rationale': 'Mejorar absorción natural y reducir escorrentía'
            })
        
        # Monitoring systems
        long_term.append({
            'priority': 'medium',
            'category': 'monitoring',
            'action': 'Instalar sensores de monitoreo en tiempo real',
            'rationale': 'Mejorar capacidad de predicción y respuesta temprana'
        })
        
        # Community preparedness
        long_term.append({
            'priority': 'low',
            'category': 'emergency',
            'action': 'Desarrollar programas de educación comunitaria',
            'rationale': 'Aumentar resiliencia y preparación de la población'
        })
        
        return long_term

# Made with Bob
