"""
Explanation service for FloodMirror AI
Generates human-readable explanations for predictions
"""
from typing import Dict, List, Tuple, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PredictionExplainer:
    """
    Generates explanations for flood risk predictions
    Provides interpretable insights into model decisions
    """
    
    def __init__(self):
        """Initialize prediction explainer"""
        # Feature descriptions in Spanish
        self.feature_descriptions = {
            'MonsoonIntensity': 'intensidad de lluvia',
            'intensidad': 'intensidad de lluvia',
            'int2': 'intensidad secundaria de lluvia',
            'TopographyDrainage': 'drenaje topográfico',
            'RiverManagement': 'gestión de ríos',
            'Deforestation': 'deforestación',
            'Urbanization': 'urbanización',
            'area_m2': 'área urbanizada',
            'DrainageSystems': 'sistemas de drenaje',
            'PopulationScore': 'densidad poblacional',
            'Watersheds': 'cuencas hidrográficas',
            'period_ret': 'período de retorno'
        }
        
        # Risk level descriptions
        self.risk_descriptions = {
            'very_low': {
                'title': 'Riesgo Muy Bajo',
                'description': 'Condiciones favorables con probabilidad mínima de inundación',
                'color': 'green'
            },
            'low': {
                'title': 'Riesgo Bajo',
                'description': 'Condiciones generalmente seguras con riesgo limitado',
                'color': 'lightgreen'
            },
            'moderate': {
                'title': 'Riesgo Moderado',
                'description': 'Condiciones que requieren atención y monitoreo',
                'color': 'yellow'
            },
            'high': {
                'title': 'Riesgo Alto',
                'description': 'Condiciones peligrosas que requieren acción preventiva',
                'color': 'orange'
            },
            'very_high': {
                'title': 'Riesgo Muy Alto',
                'description': 'Condiciones críticas que requieren acción inmediata',
                'color': 'red'
            }
        }
    
    def generate_explanation(
        self,
        risk_level: str,
        flood_probability: float,
        feature_contributions: Dict[str, float],
        missing_features: List[str],
        confidence: float
    ) -> Dict:
        """
        Generate comprehensive explanation for prediction
        
        Args:
            risk_level: Predicted risk level
            flood_probability: Flood probability (0-1)
            feature_contributions: Feature importance scores
            missing_features: List of imputed features
            confidence: Overall confidence score
            
        Returns:
            Dictionary with explanation components
        """
        # Get main contributing factors
        main_factors = self._get_main_factors(feature_contributions, top_n=3)
        
        # Generate interpretation text
        interpretation = self._generate_interpretation(
            risk_level, flood_probability, main_factors, missing_features, confidence
        )
        
        # Create detailed explanation
        explanation = {
            'main_factors': main_factors,
            'interpretation': interpretation,
            'feature_importance': feature_contributions,
            'risk_info': self.risk_descriptions.get(risk_level, {}),
            'data_quality_note': self._generate_data_quality_note(missing_features, confidence)
        }
        
        return explanation
    
    def _get_main_factors(
        self,
        feature_contributions: Dict[str, float],
        top_n: int = 3
    ) -> List[str]:
        """
        Get top contributing factors
        
        Args:
            feature_contributions: Feature importance scores
            top_n: Number of top factors to return
            
        Returns:
            List of strings with factor names and contributions formatted
        """
        # Sort by contribution
        sorted_factors = sorted(
            feature_contributions.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        # Get top N and format as strings
        main_factors = []
        for feature, contribution in sorted_factors[:top_n]:
            # Get readable name
            readable_name = self.feature_descriptions.get(feature, feature)
            # Format as string with percentage
            main_factors.append(f"{readable_name} ({contribution*100:.0f}%)")
        
        return main_factors
    
    def _generate_interpretation(
        self,
        risk_level: str,
        flood_probability: float,
        main_factors: List[str],
        missing_features: List[str],
        confidence: float
    ) -> str:
        """
        Generate human-readable interpretation
        
        Args:
            risk_level: Risk level
            flood_probability: Flood probability
            main_factors: Main contributing factors (already formatted as strings)
            missing_features: Missing features
            confidence: Confidence score
            
        Returns:
            Interpretation string in Spanish
        """
        # Start with risk level
        risk_info = self.risk_descriptions.get(risk_level, {})
        interpretation = f"{risk_info.get('title', 'Riesgo desconocido')}: "
        interpretation += f"Probabilidad de inundación del {flood_probability*100:.1f}%. "
        
        # Add main factors (already formatted as strings)
        if main_factors:
            interpretation += "Los factores principales son: "
            interpretation += ", ".join(main_factors) + ". "
        
        # Add context based on risk level
        if risk_level == 'very_high' or risk_level == 'high':
            interpretation += "Se recomienda tomar medidas preventivas inmediatas. "
        elif risk_level == 'moderate':
            interpretation += "Se recomienda monitoreo continuo y preparación preventiva. "
        else:
            interpretation += "Las condiciones actuales son favorables. "
        
        # Add confidence note
        if confidence < 0.7:
            interpretation += f"Nota: Confianza de la predicción es {confidence*100:.0f}% debido a datos limitados. "
        
        # Add missing data note
        if missing_features:
            interpretation += f"Se estimaron {len(missing_features)} parámetro(s) faltante(s). "
        
        return interpretation
    
    def _generate_data_quality_note(
        self,
        missing_features: List[str],
        confidence: float
    ) -> str:
        """
        Generate note about data quality
        
        Args:
            missing_features: List of missing features
            confidence: Confidence score
            
        Returns:
            Data quality note in Spanish
        """
        if not missing_features and confidence >= 0.9:
            return "Datos completos y de alta calidad."
        
        note = ""
        
        if missing_features:
            readable_missing = [
                self.feature_descriptions.get(f, f) 
                for f in missing_features
            ]
            note += f"Datos estimados: {', '.join(readable_missing)}. "
        
        if confidence < 0.7:
            note += "La confianza de la predicción es limitada. "
            note += "Se recomienda obtener más datos para mejorar la precisión. "
        elif confidence < 0.85:
            note += "La predicción es confiable pero podría mejorarse con datos adicionales. "
        
        return note if note else "Calidad de datos aceptable."
    
    def explain_feature_impact(
        self,
        feature_name: str,
        feature_value: float,
        contribution: float
    ) -> str:
        """
        Explain the impact of a specific feature
        
        Args:
            feature_name: Name of the feature
            feature_value: Value of the feature
            contribution: Contribution to prediction
            
        Returns:
            Explanation string
        """
        readable_name = self.feature_descriptions.get(feature_name, feature_name)
        
        impact_level = "alto" if contribution > 0.3 else "moderado" if contribution > 0.15 else "bajo"
        
        explanation = (
            f"El factor '{readable_name}' tiene un impacto {impact_level} "
            f"({contribution*100:.1f}%) en la predicción. "
        )
        
        # Add context based on feature type
        if 'intensidad' in feature_name.lower() or 'monsoon' in feature_name.lower():
            if feature_value > 0.7:
                explanation += "La intensidad de lluvia es alta, aumentando el riesgo. "
            elif feature_value < 0.3:
                explanation += "La intensidad de lluvia es baja, reduciendo el riesgo. "
        
        elif 'urbanization' in feature_name.lower() or 'area' in feature_name.lower():
            if feature_value > 0.7:
                explanation += "Alta urbanización reduce la absorción natural del agua. "
            elif feature_value < 0.3:
                explanation += "Baja urbanización permite mejor absorción del agua. "
        
        elif 'drainage' in feature_name.lower():
            if feature_value > 0.7:
                explanation += "Buenos sistemas de drenaje reducen el riesgo. "
            elif feature_value < 0.3:
                explanation += "Sistemas de drenaje deficientes aumentan el riesgo. "
        
        return explanation
    
    def generate_comparative_analysis(
        self,
        current_risk: str,
        current_probability: float,
        alcaldia: Optional[str] = None
    ) -> str:
        """
        Generate comparative analysis text
        
        Args:
            current_risk: Current risk level
            current_probability: Current flood probability
            alcaldia: Alcaldía name (optional)
            
        Returns:
            Comparative analysis text
        """
        analysis = f"Análisis de riesgo de inundación"
        
        if alcaldia:
            analysis += f" para {alcaldia}"
        
        analysis += f": {self.risk_descriptions[current_risk]['title']} "
        analysis += f"con {current_probability*100:.1f}% de probabilidad. "
        
        # Add context
        if current_probability > 0.75:
            analysis += "Este nivel de riesgo requiere atención inmediata y medidas preventivas. "
        elif current_probability > 0.5:
            analysis += "Se recomienda preparación y monitoreo continuo. "
        else:
            analysis += "El riesgo es manejable con precauciones estándar. "
        
        return analysis

# Made with Bob
