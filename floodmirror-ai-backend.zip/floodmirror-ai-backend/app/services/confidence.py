"""
Confidence calculation service for FloodMirror AI
Calculates overall confidence scores for predictions
"""
from typing import Dict, List, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ConfidenceCalculator:
    """
    Calculates confidence metrics for flood predictions
    Considers data completeness, model certainty, and Mirror penalties
    """
    
    def __init__(self):
        """Initialize confidence calculator"""
        pass
    
    def calculate_data_completeness(
        self,
        provided_features: Dict[str, float],
        required_features: List[str]
    ) -> float:
        """
        Calculate data completeness score
        
        Args:
            provided_features: Features provided by user
            required_features: All required features
            
        Returns:
            Completeness score (0-1)
        """
        if not required_features:
            return 1.0
        
        provided_count = sum(
            1 for feature in required_features 
            if feature in provided_features and provided_features[feature] is not None
        )
        
        completeness = provided_count / len(required_features)
        return completeness
    
    def calculate_model_certainty(
        self,
        prediction_probability: float,
        feature_contributions: Dict[str, float]
    ) -> float:
        """
        Calculate model prediction certainty
        
        Args:
            prediction_probability: Probability of predicted class
            feature_contributions: Feature contribution scores
            
        Returns:
            Certainty score (0-1)
        """
        # Base certainty from prediction probability
        base_certainty = prediction_probability
        
        # Adjust based on feature contribution distribution
        if feature_contributions:
            contributions = list(feature_contributions.values())
            
            # Check if contributions are well-distributed or dominated by few features
            # Higher entropy = more distributed = more certain
            if len(contributions) > 0:
                # Calculate normalized entropy
                total = sum(contributions)
                if total > 0:
                    normalized_contributions = [c / total for c in contributions]
                    entropy = -sum(
                        p * (p if p == 0 else (p * (1 if p == 1 else (1 / p))))
                        for p in normalized_contributions if p > 0
                    )
                    max_entropy = len(contributions)
                    if max_entropy > 0:
                        distribution_factor = min(entropy / max_entropy, 1.0)
                    else:
                        distribution_factor = 0.5
                else:
                    distribution_factor = 0.5
            else:
                distribution_factor = 0.5
            
            # Combine base certainty with distribution factor
            certainty = (base_certainty * 0.7) + (distribution_factor * 0.3)
        else:
            certainty = base_certainty * 0.8  # Slight penalty if no contributions
        
        return min(1.0, max(0.0, certainty))
    
    def calculate_mirror_penalty(
        self,
        missing_features: List[str],
        total_features: int,
        imputation_method: str
    ) -> float:
        """
        Calculate penalty factor for Mirror module usage
        
        Args:
            missing_features: List of imputed features
            total_features: Total number of features
            imputation_method: Method used for imputation
            
        Returns:
            Penalty factor (0-1), where 1 means no penalty
        """
        if not missing_features or imputation_method == "none":
            return 1.0
        
        # Base penalty based on proportion of missing data
        missing_ratio = len(missing_features) / total_features if total_features > 0 else 0
        
        # Method quality factors
        method_quality = {
            "contextual": 0.95,
            "knn": 0.90,
            "median": 0.85,
            "mean": 0.85,
            "default": 0.80
        }
        
        quality_factor = method_quality.get(imputation_method, 0.80)
        
        # Calculate penalty
        # More missing data = lower penalty factor
        penalty_factor = 1.0 - (missing_ratio * (1.0 - quality_factor))
        
        return max(0.0, min(1.0, penalty_factor))
    
    def calculate_overall_confidence(
        self,
        data_completeness: float,
        model_certainty: float,
        mirror_penalty: float,
        weights: Optional[Dict[str, float]] = None
    ) -> float:
        """
        Calculate overall confidence score
        
        Args:
            data_completeness: Data completeness score
            model_certainty: Model certainty score
            mirror_penalty: Mirror penalty factor
            weights: Optional custom weights for each component
            
        Returns:
            Overall confidence score (0-1)
        """
        # Default weights
        if weights is None:
            weights = {
                'data_completeness': 0.35,
                'model_certainty': 0.40,
                'mirror_penalty': 0.25
            }
        
        # Normalize weights
        total_weight = sum(weights.values())
        if total_weight > 0:
            weights = {k: v / total_weight for k, v in weights.items()}
        
        # Calculate weighted average
        overall = (
            data_completeness * weights['data_completeness'] +
            model_certainty * weights['model_certainty'] +
            mirror_penalty * weights['mirror_penalty']
        )
        
        return min(1.0, max(0.0, overall))
    
    def get_confidence_level_description(self, confidence: float) -> str:
        """
        Get human-readable confidence level description
        
        Args:
            confidence: Confidence score (0-1)
            
        Returns:
            Description string in Spanish
        """
        if confidence >= 0.9:
            return "Muy alta - Datos completos y predicción muy confiable"
        elif confidence >= 0.75:
            return "Alta - Predicción confiable con datos suficientes"
        elif confidence >= 0.6:
            return "Media - Predicción aceptable, algunos datos estimados"
        elif confidence >= 0.4:
            return "Baja - Varios datos estimados, usar con precaución"
        else:
            return "Muy baja - Muchos datos faltantes, predicción poco confiable"
    
    def calculate_all_metrics(
        self,
        provided_features: Dict[str, float],
        required_features: List[str],
        prediction_probability: float,
        feature_contributions: Dict[str, float],
        missing_features: List[str],
        imputation_method: str
    ) -> Dict[str, float]:
        """
        Calculate all confidence metrics at once
        
        Args:
            provided_features: Features provided by user
            required_features: All required features
            prediction_probability: Model prediction probability
            feature_contributions: Feature importance scores
            missing_features: List of imputed features
            imputation_method: Imputation method used
            
        Returns:
            Dictionary with all confidence metrics
        """
        data_completeness = self.calculate_data_completeness(
            provided_features, required_features
        )
        
        model_certainty = self.calculate_model_certainty(
            prediction_probability, feature_contributions
        )
        
        mirror_penalty = self.calculate_mirror_penalty(
            missing_features, len(required_features), imputation_method
        )
        
        overall_confidence = self.calculate_overall_confidence(
            data_completeness, model_certainty, mirror_penalty
        )
        
        logger.info(
            f"Confidence metrics - Overall: {overall_confidence:.3f}, "
            f"Data: {data_completeness:.3f}, Model: {model_certainty:.3f}, "
            f"Mirror: {mirror_penalty:.3f}"
        )
        
        return {
            'overall_confidence': overall_confidence,
            'data_completeness': data_completeness,
            'model_certainty': model_certainty,
            'mirror_penalty': mirror_penalty
        }

# Made with Bob
