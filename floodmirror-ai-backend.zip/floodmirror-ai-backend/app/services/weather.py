"""
Weather service integration with Open-Meteo API
Provides real-time weather data for flood risk assessment
"""
import httpx
import logging
from typing import Dict, Optional, Tuple
from datetime import datetime

logger = logging.getLogger(__name__)


class WeatherService:
    """
    Integration with Open-Meteo API for weather data
    """
    
    BASE_URL = "https://api.open-meteo.com/v1/forecast"
    
    def __init__(self):
        self.client = httpx.AsyncClient(timeout=10.0)
    
    async def get_weather_data(
        self, 
        latitude: float, 
        longitude: float
    ) -> Optional[Dict]:
        """
        Get current weather data and forecast from Open-Meteo
        
        Args:
            latitude: Location latitude
            longitude: Location longitude
            
        Returns:
            Dictionary with weather data or None if error
        """
        try:
            params = {
                "latitude": latitude,
                "longitude": longitude,
                "current": "temperature_2m,precipitation,rain,weather_code",
                "hourly": "precipitation_probability,precipitation,rain",
                "timezone": "America/Mexico_City",
                "forecast_days": 1
            }
            
            response = await self.client.get(self.BASE_URL, params=params)
            response.raise_for_status()
            
            data = response.json()
            logger.info(f"Weather data retrieved for ({latitude}, {longitude})")
            
            return data
            
        except Exception as e:
            logger.error(f"Error fetching weather data: {e}")
            return None
    
    def calculate_weather_risk_factor(
        self, 
        weather_data: Optional[Dict]
    ) -> Tuple[float, Dict]:
        """
        Calculate weather risk factor from weather data
        
        Args:
            weather_data: Weather data from Open-Meteo
            
        Returns:
            Tuple of (risk_factor, weather_info)
            risk_factor: 0.0 to 1.0 (0 = no risk, 1 = extreme risk)
            weather_info: Dictionary with weather details
        """
        if not weather_data:
            return 0.0, {
                "status": "unavailable",
                "current_rain": 0.0,
                "rain_probability": 0.0,
                "description": "Datos meteorológicos no disponibles"
            }
        
        try:
            current = weather_data.get("current", {})
            hourly = weather_data.get("hourly", {})
            
            # Current precipitation
            current_rain = current.get("rain", 0.0) or 0.0
            current_precip = current.get("precipitation", 0.0) or 0.0
            
            # Hourly forecast (next 6 hours)
            rain_probs = hourly.get("precipitation_probability", [])[:6]
            hourly_precip = hourly.get("precipitation", [])[:6]
            
            # Calculate average rain probability
            avg_rain_prob = sum(rain_probs) / len(rain_probs) if rain_probs else 0.0
            
            # Calculate expected precipitation
            expected_precip = sum(hourly_precip) / len(hourly_precip) if hourly_precip else 0.0
            
            # Calculate risk factor
            # Components:
            # 1. Current rain intensity (0-50mm/h normalized)
            current_risk = min(current_rain / 50.0, 1.0) * 0.4
            
            # 2. Rain probability (0-100% normalized)
            probability_risk = (avg_rain_prob / 100.0) * 0.3
            
            # 3. Expected precipitation intensity
            expected_risk = min(expected_precip / 30.0, 1.0) * 0.3
            
            weather_risk_factor = current_risk + probability_risk + expected_risk
            weather_risk_factor = min(weather_risk_factor, 1.0)
            
            # Determine description
            if weather_risk_factor < 0.2:
                description = "Condiciones meteorológicas favorables"
            elif weather_risk_factor < 0.4:
                description = "Lluvia ligera esperada"
            elif weather_risk_factor < 0.6:
                description = "Lluvia moderada en curso o esperada"
            elif weather_risk_factor < 0.8:
                description = "Lluvia intensa - precaución recomendada"
            else:
                description = "Condiciones meteorológicas extremas - alto riesgo"
            
            weather_info = {
                "status": "available",
                "current_rain": round(current_rain, 2),
                "current_precipitation": round(current_precip, 2),
                "rain_probability": round(avg_rain_prob, 1),
                "expected_precipitation": round(expected_precip, 2),
                "weather_risk_factor": round(weather_risk_factor, 3),
                "description": description,
                "timestamp": datetime.now().isoformat()
            }
            
            logger.info(f"Weather risk factor calculated: {weather_risk_factor:.3f}")
            
            return weather_risk_factor, weather_info
            
        except Exception as e:
            logger.error(f"Error calculating weather risk: {e}")
            return 0.0, {
                "status": "error",
                "current_rain": 0.0,
                "rain_probability": 0.0,
                "description": "Error al procesar datos meteorológicos"
            }
    
    async def close(self):
        """Close HTTP client"""
        await self.client.aclose()


# Global instance
_weather_service: Optional[WeatherService] = None


def get_weather_service() -> WeatherService:
    """Get or create global weather service instance"""
    global _weather_service
    if _weather_service is None:
        _weather_service = WeatherService()
    return _weather_service

# Made with Bob
