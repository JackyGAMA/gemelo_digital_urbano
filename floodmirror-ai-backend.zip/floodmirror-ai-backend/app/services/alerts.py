"""
Intelligent alerts system
Combines historical risk with real-time weather data
"""
import logging
from typing import Dict, List, Optional
from enum import Enum

logger = logging.getLogger(__name__)


class AlertLevel(str, Enum):
    """Alert severity levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class AlertType(str, Enum):
    """Types of alerts"""
    WEATHER = "weather"
    HISTORICAL = "historical"
    COMBINED = "combined"
    INFRASTRUCTURE = "infrastructure"


class AlertSystem:
    """
    Intelligent alert system that combines multiple risk factors
    """
    
    def generate_alert(
        self,
        historical_risk_factor: float,
        weather_risk_factor: float,
        flood_probability: float,
        alcaldia: Optional[str] = None,
        weather_info: Optional[Dict] = None
    ) -> Dict:
        """
        Generate intelligent alert based on multiple risk factors
        
        Args:
            historical_risk_factor: Historical flood risk (0-1)
            weather_risk_factor: Current weather risk (0-1)
            flood_probability: Model prediction probability (0-1)
            alcaldia: Location name
            weather_info: Weather details
            
        Returns:
            Dictionary with alert information
        """
        # Calculate combined risk score
        # Weights: historical 40%, weather 35%, model 25%
        final_risk_score = (
            historical_risk_factor * 0.40 +
            weather_risk_factor * 0.35 +
            flood_probability * 0.25
        )
        
        # Determine alert level
        alert_level = self._calculate_alert_level(
            final_risk_score,
            weather_risk_factor,
            historical_risk_factor
        )
        
        # Generate alert message
        alert_message = self._generate_alert_message(
            alert_level,
            final_risk_score,
            historical_risk_factor,
            weather_risk_factor,
            alcaldia,
            weather_info
        )
        
        # Generate recommendations
        recommendations = self._generate_alert_recommendations(
            alert_level,
            weather_risk_factor,
            historical_risk_factor
        )
        
        alert = {
            "alert_level": alert_level.value,
            "final_risk_score": round(final_risk_score, 3),
            "components": {
                "historical_risk": round(historical_risk_factor, 3),
                "weather_risk": round(weather_risk_factor, 3),
                "model_prediction": round(flood_probability, 3)
            },
            "message": alert_message,
            "recommendations": recommendations,
            "requires_action": alert_level in [AlertLevel.HIGH, AlertLevel.CRITICAL],
            "location": alcaldia,
            "weather_details": weather_info
        }
        
        logger.info(
            f"Alert generated: {alert_level.value} "
            f"(score: {final_risk_score:.3f}) for {alcaldia or 'unknown location'}"
        )
        
        return alert
    
    def _calculate_alert_level(
        self,
        final_risk_score: float,
        weather_risk: float,
        historical_risk: float
    ) -> AlertLevel:
        """
        Determine alert level based on risk scores
        
        Special conditions:
        - CRITICAL if weather_risk > 0.7 AND historical_risk > 0.6
        - HIGH if either weather_risk > 0.6 OR (historical_risk > 0.7 AND weather_risk > 0.3)
        """
        # Critical conditions
        if weather_risk > 0.7 and historical_risk > 0.6:
            return AlertLevel.CRITICAL
        
        # High alert conditions
        if weather_risk > 0.6 or (historical_risk > 0.7 and weather_risk > 0.3):
            return AlertLevel.HIGH
        
        # Standard thresholds
        if final_risk_score >= 0.7:
            return AlertLevel.HIGH
        elif final_risk_score >= 0.5:
            return AlertLevel.MEDIUM
        elif final_risk_score >= 0.3:
            return AlertLevel.LOW
        else:
            return AlertLevel.LOW
    
    def _generate_alert_message(
        self,
        alert_level: AlertLevel,
        final_risk_score: float,
        historical_risk: float,
        weather_risk: float,
        alcaldia: Optional[str],
        weather_info: Optional[Dict]
    ) -> str:
        """Generate human-readable alert message"""
        
        location_str = f" en {alcaldia}" if alcaldia else ""
        
        if alert_level == AlertLevel.CRITICAL:
            message = (
                f"⚠️ ALERTA CRÍTICA{location_str}: "
                f"Condiciones meteorológicas extremas combinadas con zona de alto riesgo histórico. "
                f"Riesgo de inundación muy elevado ({final_risk_score*100:.0f}%). "
            )
            if weather_info and weather_info.get("current_rain", 0) > 0:
                message += f"Lluvia actual: {weather_info['current_rain']} mm/h. "
            message += "Se recomienda evacuar a zonas seguras inmediatamente."
            
        elif alert_level == AlertLevel.HIGH:
            message = (
                f"⚠️ ALERTA ALTA{location_str}: "
                f"Riesgo significativo de inundación ({final_risk_score*100:.0f}%). "
            )
            if weather_risk > 0.5:
                message += "Condiciones meteorológicas adversas detectadas. "
            if historical_risk > 0.6:
                message += "Zona con historial de inundaciones frecuentes. "
            message += "Manténgase alerta y prepare medidas preventivas."
            
        elif alert_level == AlertLevel.MEDIUM:
            message = (
                f"⚡ ALERTA MODERADA{location_str}: "
                f"Riesgo moderado de inundación ({final_risk_score*100:.0f}%). "
            )
            if weather_risk > 0.3:
                message += "Condiciones meteorológicas a monitorear. "
            message += "Revise rutas de evacuación y mantenga informado."
            
        else:  # LOW
            message = (
                f"✓ RIESGO BAJO{location_str}: "
                f"Condiciones actuales favorables ({final_risk_score*100:.0f}% riesgo). "
            )
            if historical_risk > 0.3:
                message += "Zona con historial de inundaciones ocasionales. "
            message += "Mantenga precauciones básicas."
        
        return message
    
    def _generate_alert_recommendations(
        self,
        alert_level: AlertLevel,
        weather_risk: float,
        historical_risk: float
    ) -> List[str]:
        """Generate specific recommendations based on alert level"""
        
        recommendations = []
        
        if alert_level == AlertLevel.CRITICAL:
            recommendations.extend([
                "Evacuar inmediatamente a zonas elevadas o refugios seguros",
                "Llamar al 911 si requiere asistencia de emergencia",
                "No intentar cruzar calles inundadas a pie o en vehículo",
                "Mantener teléfono cargado y radio encendido",
                "Seguir instrucciones de autoridades de Protección Civil"
            ])
            
        elif alert_level == AlertLevel.HIGH:
            recommendations.extend([
                "Preparar kit de emergencia (agua, alimentos, documentos)",
                "Identificar rutas de evacuación hacia zonas seguras",
                "Mover objetos de valor a lugares elevados",
                "Evitar sótanos y áreas bajas",
                "Monitorear alertas de Protección Civil CDMX"
            ])
            if weather_risk > 0.5:
                recommendations.append("Evitar desplazamientos innecesarios durante la lluvia")
            
        elif alert_level == AlertLevel.MEDIUM:
            recommendations.extend([
                "Revisar que coladeras cercanas estén despejadas",
                "Tener a mano números de emergencia (911, 072)",
                "Verificar que drenajes funcionen correctamente",
                "Mantener informado sobre pronóstico del tiempo"
            ])
            if historical_risk > 0.4:
                recommendations.append("Considerar medidas preventivas adicionales por historial de la zona")
            
        else:  # LOW
            recommendations.extend([
                "Mantener precauciones básicas de seguridad",
                "Reportar coladeras obstruidas al 072",
                "Conocer ubicación de refugios cercanos"
            ])
        
        return recommendations


# Global instance
_alert_system: Optional[AlertSystem] = None


def get_alert_system() -> AlertSystem:
    """Get or create global alert system instance"""
    global _alert_system
    if _alert_system is None:
        _alert_system = AlertSystem()
    return _alert_system

# Made with Bob
