"""
Data loading utilities for FloodMirror AI
Handles loading and preprocessing of CSV datasets
"""
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Tuple, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DataLoader:
    """
    Handles loading and preprocessing of flood and CDMX datasets
    """
    
    def __init__(self, data_dir: str = "data"):
        """
        Initialize DataLoader
        
        Args:
            data_dir: Directory containing CSV files
        """
        self.data_dir = Path(data_dir)
        self.flood_data: Optional[pd.DataFrame] = None
        self.cdmx_data: Optional[pd.DataFrame] = None
        
    def load_flood_data(self, filename: str = "flood_clean.csv") -> pd.DataFrame:
        """
        Load flood dataset
        
        Expected columns:
        - MonsoonIntensity
        - TopographyDrainage
        - RiverManagement
        - Deforestation
        - Urbanization
        - DrainageSystems
        - PopulationScore
        - Watersheds
        - FloodProbability
        
        Args:
            filename: Name of the flood CSV file
            
        Returns:
            DataFrame with flood data
        """
        filepath = self.data_dir / filename
        
        try:
            self.flood_data = pd.read_csv(filepath)
            logger.info(f"Loaded flood data: {self.flood_data.shape[0]} rows, {self.flood_data.shape[1]} columns")
            
            # Validate required columns
            required_cols = [
                'MonsoonIntensity', 'TopographyDrainage', 'RiverManagement',
                'Deforestation', 'Urbanization', 'DrainageSystems',
                'PopulationScore', 'Watersheds', 'FloodProbability'
            ]
            
            missing_cols = [col for col in required_cols if col not in self.flood_data.columns]
            if missing_cols:
                logger.warning(f"Missing columns in flood data: {missing_cols}")
            
            # Handle missing values
            self.flood_data = self._handle_missing_values(self.flood_data)
            
            return self.flood_data
            
        except FileNotFoundError:
            logger.error(f"Flood data file not found: {filepath}")
            raise
        except Exception as e:
            logger.error(f"Error loading flood data: {str(e)}")
            raise
    
    def load_cdmx_data(self, filename: str = "cdmx_clean.csv") -> pd.DataFrame:
        """
        Load CDMX dataset
        
        Expected columns:
        - alcaldia
        - intensidad
        - int2
        - area_m2
        - period_ret
        - latitud
        - longitud
        
        Args:
            filename: Name of the CDMX CSV file
            
        Returns:
            DataFrame with CDMX data
        """
        filepath = self.data_dir / filename
        
        try:
            self.cdmx_data = pd.read_csv(filepath)
            logger.info(f"Loaded CDMX data: {self.cdmx_data.shape[0]} rows, {self.cdmx_data.shape[1]} columns")
            
            # Validate required columns
            required_cols = [
                'alcaldia', 'intensidad', 'int2', 'area_m2',
                'period_ret', 'latitud', 'longitud'
            ]
            
            missing_cols = [col for col in required_cols if col not in self.cdmx_data.columns]
            if missing_cols:
                logger.warning(f"Missing columns in CDMX data: {missing_cols}")
            
            # Handle missing values
            self.cdmx_data = self._handle_missing_values(self.cdmx_data)
            
            return self.cdmx_data
            
        except FileNotFoundError:
            logger.error(f"CDMX data file not found: {filepath}")
            raise
        except Exception as e:
            logger.error(f"Error loading CDMX data: {str(e)}")
            raise
    
    def _handle_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Handle missing values in dataset
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with handled missing values
        """
        # For numeric columns, fill with median
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            if df[col].isnull().any():
                median_val = df[col].median()
                df[col].fillna(median_val, inplace=True)
                logger.info(f"Filled {col} missing values with median: {median_val}")
        
        # For categorical columns, fill with mode
        categorical_cols = df.select_dtypes(include=['object']).columns
        for col in categorical_cols:
            if df[col].isnull().any():
                mode_val = df[col].mode()[0] if not df[col].mode().empty else "Unknown"
                df[col].fillna(mode_val, inplace=True)
                logger.info(f"Filled {col} missing values with mode: {mode_val}")
        
        return df
    
    def get_feature_statistics(self, dataset: str = "flood") -> dict:
        """
        Get statistical summary of features
        
        Args:
            dataset: "flood" or "cdmx"
            
        Returns:
            Dictionary with feature statistics
        """
        df = self.flood_data if dataset == "flood" else self.cdmx_data
        
        if df is None:
            raise ValueError(f"{dataset} data not loaded")
        
        stats = {}
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        
        for col in numeric_cols:
            stats[col] = {
                'mean': float(df[col].mean()),
                'median': float(df[col].median()),
                'std': float(df[col].std()),
                'min': float(df[col].min()),
                'max': float(df[col].max()),
                'q25': float(df[col].quantile(0.25)),
                'q75': float(df[col].quantile(0.75))
            }
        
        return stats
    
    def load_all_data(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Load both flood and CDMX datasets
        
        Returns:
            Tuple of (flood_data, cdmx_data)
        """
        flood_df = self.load_flood_data()
        cdmx_df = self.load_cdmx_data()
        return flood_df, cdmx_df
    
    def get_alcaldia_stats(self, alcaldia: str) -> Optional[dict]:
        """
        Get statistics for a specific alcaldía
        
        Args:
            alcaldia: Name of the alcaldía
            
        Returns:
            Dictionary with alcaldía statistics or None if not found
        """
        if self.cdmx_data is None:
            raise ValueError("CDMX data not loaded")
        
        alcaldia_data = self.cdmx_data[self.cdmx_data['alcaldia'] == alcaldia]
        
        if alcaldia_data.empty:
            return None
        
        numeric_cols = alcaldia_data.select_dtypes(include=[np.number]).columns
        stats = {
            'count': len(alcaldia_data),
            'features': {}
        }
        
        for col in numeric_cols:
            stats['features'][col] = {
                'mean': float(alcaldia_data[col].mean()),
                'median': float(alcaldia_data[col].median()),
                'min': float(alcaldia_data[col].min()),
                'max': float(alcaldia_data[col].max())
            }
        
        return stats

# Made with Bob
