"""
Mirror Module for FloodMirror AI
Handles missing data imputation using intelligent strategies
"""
import pandas as pd
import numpy as np
from sklearn.impute import KNNImputer, SimpleImputer
from typing import Dict, List, Tuple, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MirrorModule:
    """
    Mirror module for handling missing data in flood predictions
    Uses multiple imputation strategies based on data availability
    """
    
    def __init__(self, reference_data: Optional[pd.DataFrame] = None):
        """
        Initialize Mirror module
        
        Args:
            reference_data: Reference dataset for statistical imputation
        """
        self.reference_data = reference_data
        self.knn_imputer = KNNImputer(n_neighbors=5, weights='distance')
        self.simple_imputer = SimpleImputer(strategy='median')
        self.feature_stats: Optional[Dict[str, Dict[str, float]]] = None
        
        if reference_data is not None:
            self._compute_feature_statistics()
    
    def _compute_feature_statistics(self):
        """Compute statistical summaries of reference data"""
        if self.reference_data is None:
            return
        
        self.feature_stats = {}
        numeric_cols = self.reference_data.select_dtypes(include=[np.number]).columns
        
        for col in numeric_cols:
            self.feature_stats[col] = {
                'mean': float(self.reference_data[col].mean()),
                'median': float(self.reference_data[col].median()),
                'std': float(self.reference_data[col].std()),
                'min': float(self.reference_data[col].min()),
                'max': float(self.reference_data[col].max()),
                'q25': float(self.reference_data[col].quantile(0.25)),
                'q75': float(self.reference_data[col].quantile(0.75))
            }
        
        logger.info(f"Computed statistics for {len(self.feature_stats)} features")
    
    def detect_missing_features(
        self, 
        input_features: Dict[str, float], 
        required_features: List[str]
    ) -> List[str]:
        """
        Detect which required features are missing from input
        
        Args:
            input_features: Dictionary of provided features
            required_features: List of required feature names
            
        Returns:
            List of missing feature names
        """
        missing = []
        for feature in required_features:
            if feature not in input_features or input_features[feature] is None:
                missing.append(feature)
        
        return missing
    
    def impute_missing_features(
        self,
        input_features: Dict[str, float],
        required_features: List[str],
        method: str = "auto"
    ) -> Tuple[Dict[str, float], List[str], str]:
        """
        Impute missing features using appropriate strategy
        
        Args:
            input_features: Dictionary of provided features
            required_features: List of required feature names
            method: Imputation method ("auto", "median", "mean", "knn", "contextual")
            
        Returns:
            Tuple of (complete_features, imputed_fields, method_used)
        """
        missing_features = self.detect_missing_features(input_features, required_features)
        
        if not missing_features:
            return input_features, [], "none"
        
        logger.info(f"Imputing {len(missing_features)} missing features: {missing_features}")
        
        # Choose imputation method
        if method == "auto":
            # Use contextual if we have reference data and few missing features
            if self.reference_data is not None and len(missing_features) <= 3:
                method = "contextual"
            else:
                method = "median"
        
        complete_features = input_features.copy()
        
        if method == "median" or method == "mean":
            complete_features = self._impute_statistical(
                complete_features, missing_features, method
            )
        elif method == "knn":
            complete_features = self._impute_knn(
                complete_features, required_features, missing_features
            )
        elif method == "contextual":
            complete_features = self._impute_contextual(
                complete_features, missing_features
            )
        
        return complete_features, missing_features, method
    
    def _impute_statistical(
        self,
        features: Dict[str, float],
        missing_features: List[str],
        method: str
    ) -> Dict[str, float]:
        """
        Impute using statistical measures (mean/median)
        
        Args:
            features: Feature dictionary
            missing_features: List of missing feature names
            method: "mean" or "median"
            
        Returns:
            Dictionary with imputed features
        """
        if self.feature_stats is None:
            logger.warning("No feature statistics available, using default values")
            # Use reasonable defaults
            for feature in missing_features:
                features[feature] = 0.5  # Middle value for normalized features
            return features
        
        for feature in missing_features:
            if feature in self.feature_stats:
                if method == "median":
                    features[feature] = self.feature_stats[feature]['median']
                else:
                    features[feature] = self.feature_stats[feature]['mean']
                logger.info(f"Imputed {feature} with {method}: {features[feature]:.4f}")
            else:
                features[feature] = 0.5
                logger.warning(f"No statistics for {feature}, using default: 0.5")
        
        return features
    
    def _impute_knn(
        self,
        features: Dict[str, float],
        required_features: List[str],
        missing_features: List[str]
    ) -> Dict[str, float]:
        """
        Impute using K-Nearest Neighbors
        
        Args:
            features: Feature dictionary
            required_features: All required features
            missing_features: Missing feature names
            
        Returns:
            Dictionary with imputed features
        """
        if self.reference_data is None:
            logger.warning("No reference data for KNN, falling back to median")
            return self._impute_statistical(features, missing_features, "median")
        
        # Create a row with the input features
        input_row = []
        for feature in required_features:
            if feature in features:
                input_row.append(features[feature])
            else:
                input_row.append(np.nan)
        
        # Combine with reference data
        ref_subset = self.reference_data[required_features].copy()
        input_df = pd.DataFrame([input_row], columns=required_features)
        combined = pd.concat([ref_subset, input_df], ignore_index=True)
        
        # Apply KNN imputation
        imputed = self.knn_imputer.fit_transform(combined)
        imputed_row = imputed[-1]
        
        # Update features
        for i, feature in enumerate(required_features):
            if feature in missing_features:
                features[feature] = float(imputed_row[i])
                logger.info(f"KNN imputed {feature}: {features[feature]:.4f}")
        
        return features
    
    def _impute_contextual(
        self,
        features: Dict[str, float],
        missing_features: List[str]
    ) -> Dict[str, float]:
        """
        Impute using contextual relationships between features
        
        Args:
            features: Feature dictionary
            missing_features: Missing feature names
            
        Returns:
            Dictionary with imputed features
        """
        # Define contextual relationships
        relationships = {
            'DrainageSystems': ['Urbanization', 'PopulationScore'],
            'TopographyDrainage': ['Watersheds', 'RiverManagement'],
            'Deforestation': ['Urbanization'],
            'PopulationScore': ['Urbanization'],
            'RiverManagement': ['Watersheds', 'TopographyDrainage']
        }
        
        for feature in missing_features:
            if feature in relationships:
                related_features = relationships[feature]
                related_values = [
                    features[rf] for rf in related_features 
                    if rf in features and features[rf] is not None
                ]
                
                if related_values:
                    # Use weighted average of related features
                    imputed_value = np.mean(related_values)
                    features[feature] = float(imputed_value)
                    logger.info(f"Contextually imputed {feature}: {imputed_value:.4f}")
                else:
                    # Fall back to median
                    if self.feature_stats and feature in self.feature_stats:
                        features[feature] = self.feature_stats[feature]['median']
                    else:
                        features[feature] = 0.5
            else:
                # No contextual relationship, use median
                if self.feature_stats and feature in self.feature_stats:
                    features[feature] = self.feature_stats[feature]['median']
                else:
                    features[feature] = 0.5
        
        return features
    
    def calculate_imputation_confidence(
        self,
        missing_features: List[str],
        total_features: int,
        method: str
    ) -> float:
        """
        Calculate confidence penalty based on imputation
        
        Args:
            missing_features: List of imputed features
            total_features: Total number of features
            method: Imputation method used
            
        Returns:
            Confidence score (0-1), where 1 is full confidence
        """
        if not missing_features:
            return 1.0
        
        # Base penalty for missing data
        missing_ratio = len(missing_features) / total_features
        base_confidence = 1.0 - (missing_ratio * 0.5)  # Max 50% penalty
        
        # Method-specific adjustments
        method_confidence = {
            "none": 1.0,
            "contextual": 0.95,
            "knn": 0.90,
            "median": 0.85,
            "mean": 0.85
        }
        
        method_factor = method_confidence.get(method, 0.80)
        
        # Combined confidence
        final_confidence = base_confidence * method_factor
        
        return max(0.0, min(1.0, final_confidence))
    
    def get_imputation_explanation(
        self,
        missing_features: List[str],
        method: str
    ) -> str:
        """
        Generate human-readable explanation of imputation
        
        Args:
            missing_features: List of imputed features
            method: Imputation method used
            
        Returns:
            Explanation string
        """
        if not missing_features:
            return "Todos los datos necesarios fueron proporcionados."
        
        method_descriptions = {
            "median": "valores medianos del conjunto de datos histórico",
            "mean": "valores promedio del conjunto de datos histórico",
            "knn": "valores similares de casos históricos cercanos",
            "contextual": "relaciones contextuales entre características relacionadas"
        }
        
        method_desc = method_descriptions.get(method, "métodos estadísticos")
        
        feature_list = ", ".join(missing_features)
        
        explanation = (
            f"Se estimaron {len(missing_features)} parámetro(s) faltante(s) "
            f"({feature_list}) usando {method_desc}. "
            f"Esto puede afectar la precisión de la predicción."
        )
        
        return explanation

# Made with Bob
