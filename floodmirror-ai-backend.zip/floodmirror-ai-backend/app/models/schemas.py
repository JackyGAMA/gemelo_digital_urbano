"""
Pydantic schemas for FloodMirror AI API
Defines request and response models for the FastAPI endpoints
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum


class RiskLevel(str, Enum):
    """Enum for flood risk levels"""
    VERY_LOW = "very_low"
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    VERY_HIGH = "very_high"


class FloodPredictionRequest(BaseModel):
    """
    Request model for flood prediction
    Accepts data from CDMX or general flood parameters
    """
    # CDMX specific fields
    alcaldia: Optional[str] = Field(None, description="Alcaldía de CDMX")
    intensidad: Optional[float] = Field(None, description="Intensidad de lluvia (mm/h)")
    int2: Optional[float] = Field(None, description="Intensidad secundaria")
    area_m2: Optional[float] = Field(None, description="Área en metros cuadrados")
    period_ret: Optional[float] = Field(None, description="Período de retorno")
    latitud: Optional[float] = Field(None, ge=-90, le=90, description="Latitud")
    longitud: Optional[float] = Field(None, ge=-180, le=180, description="Longitud")
    
    # General flood parameters
    monsoon_intensity: Optional[float] = Field(None, description="Intensidad del monzón")
    topography_drainage: Optional[float] = Field(None, description="Drenaje topográfico")
    river_management: Optional[float] = Field(None, description="Gestión de ríos")
    deforestation: Optional[float] = Field(None, description="Nivel de deforestación")
    urbanization: Optional[float] = Field(None, description="Nivel de urbanización")
    drainage_systems: Optional[float] = Field(None, description="Calidad de sistemas de drenaje")
    population_score: Optional[float] = Field(None, description="Puntuación de población")
    watersheds: Optional[float] = Field(None, description="Cuencas hidrográficas")
    
    class Config:
        json_schema_extra = {
            "example": {
                "alcaldia": "Iztapalapa",
                "intensidad": 45.5,
                "int2": 38.2,
                "area_m2": 5000.0,
                "period_ret": 10.0,
                "latitud": 19.3573,
                "longitud": -99.0699
            }
        }


class MirrorInfo(BaseModel):
    """Information about Mirror module activation"""
    activated: bool = Field(..., description="Whether Mirror module was activated")
    missing_fields: List[str] = Field(default_factory=list, description="List of missing fields")
    imputed_fields: List[str] = Field(default_factory=list, description="List of imputed fields")
    imputation_method: Optional[str] = Field(None, description="Method used for imputation")


class ConfidenceMetrics(BaseModel):
    """Confidence metrics for the prediction"""
    overall_confidence: float = Field(..., ge=0, le=1, description="Overall confidence score (0-1)")
    data_completeness: float = Field(..., ge=0, le=1, description="Data completeness score")
    model_certainty: float = Field(..., ge=0, le=1, description="Model prediction certainty")
    mirror_penalty: float = Field(..., ge=0, le=1, description="Penalty applied due to Mirror usage")


class Explanation(BaseModel):
    """Explanation of the prediction"""
    main_factors: List[str] = Field(..., description="Main contributing factors with percentages")
    interpretation: str = Field(..., description="Human-readable interpretation")
    feature_importance: Dict[str, float] = Field(..., description="Feature importance scores")


class Recommendation(BaseModel):
    """Individual recommendation"""
    priority: str = Field(..., description="Priority level: high, medium, low")
    category: str = Field(..., description="Category: infrastructure, monitoring, emergency")
    action: str = Field(..., description="Recommended action")
    rationale: str = Field(..., description="Reason for this recommendation")


class FloodPredictionResponse(BaseModel):
    """
    Response model for flood prediction
    Contains prediction, confidence, explanation, and recommendations
    """
    risk_level: RiskLevel = Field(..., description="Predicted flood risk level")
    flood_probability: float = Field(..., ge=0, le=1, description="Probability of flooding (0-1)")
    confidence: ConfidenceMetrics = Field(..., description="Confidence metrics")
    mirror_info: MirrorInfo = Field(..., description="Mirror module information")
    explanation: Explanation = Field(..., description="Prediction explanation")
    recommendations: List[Recommendation] = Field(..., description="Actionable recommendations")
    location_info: Optional[Dict[str, Any]] = Field(None, description="Location-specific information")
    
    class Config:
        json_schema_extra = {
            "example": {
                "risk_level": "high",
                "flood_probability": 0.78,
                "confidence": {
                    "overall_confidence": 0.85,
                    "data_completeness": 0.90,
                    "model_certainty": 0.88,
                    "mirror_penalty": 0.95
                },
                "mirror_info": {
                    "activated": True,
                    "missing_fields": ["drainage_systems"],
                    "imputed_fields": ["drainage_systems"],
                    "imputation_method": "knn"
                },
                "explanation": {
                    "main_factors": [
                        {"intensidad": 0.35},
                        {"urbanization": 0.28}
                    ],
                    "interpretation": "Alto riesgo debido a intensidad de lluvia elevada y alta urbanización",
                    "feature_importance": {
                        "intensidad": 0.35,
                        "urbanization": 0.28
                    }
                },
                "recommendations": [
                    {
                        "priority": "high",
                        "category": "emergency",
                        "action": "Activar sistema de alerta temprana",
                        "rationale": "Probabilidad de inundación superior al 75%"
                    }
                ]
            }
        }


class HealthResponse(BaseModel):
    """Health check response"""
    status: str = Field(..., description="API status")
    version: str = Field(..., description="API version")
    model_loaded: bool = Field(..., description="Whether ML model is loaded")
    data_loaded: bool = Field(..., description="Whether training data is loaded")

# Made with Bob
