# Plan Detallado de Trabajo - FloodMirror AI
## Integración de Datos Oficiales CDMX

**Fecha de Inicio:** 2026-06-06  
**Equipo:** Data Scientist Senior + Ingeniero GIS Senior + Ingeniero ML Senior

---

## 📊 INVENTARIO DE DATASETS

### Datasets Disponibles

1. **Atlas de Riesgo de Precipitación CDMX**
   - Formato: CSV
   - Ubicación: `C:\Users\jacqu\Downloads\datassets\atlas-de-riesgo-precipitacion.csv`
   - Fuente: Datos oficiales CDMX
   - Estado: ✅ Disponible

2. **Sitios Recurrentes de Encharcamiento**
   - Formato: Shapefile (.shp)
   - Ubicación: `C:\Users\jacqu\Downloads\datassets\sitios-recurrentes-de-encharcamiento-en-ciudad-de-mexico (1)\Sitios recurrentes de encharcamiento en Ciudad de Me¦üxico\sitios_mayor_recurrencia_encharcamientos.shp`
   - Fuente: Datos oficiales CDMX
   - Estado: ✅ Disponible

3. **Características de Viviendas por AGEB**
   - Formato: Shapefile (.shp)
   - Ubicación: `C:\Users\jacqu\Downloads\datassets\c_viviendas_ageb_v2\c_viviendas_ageb.shp`
   - Fuente: INEGI
   - Estado: ✅ Disponible

4. **CDMX Clean (Existente)**
   - Formato: CSV
   - Ubicación: `C:\Users\jacqu\Downloads\datassets\cdmx_clean.csv`
   - Estado: ✅ Disponible (requiere validación)

### Datasets Sintéticos a Reemplazar

- `floodmirror-ai-backend/data/flood_clean.csv` - **SERÁ REEMPLAZADO** con datos procesados de fuentes oficiales

---

## 🎯 FASES DEL PROYECTO

### FASE 1: AUDITORÍA DE DATOS ✅ EN PROGRESO

**Objetivo:** Analizar calidad, estructura y problemas de cada dataset

**Tareas:**
- [x] Crear script de auditoría (`scripts/01_data_audit.py`)
- [ ] Ejecutar auditoría completa
- [ ] Generar reporte de calidad JSON
- [ ] Generar resumen ejecutivo TXT
- [ ] Identificar problemas críticos

**Análisis por Dataset:**

1. **Atlas de Riesgo de Precipitación**
   - Verificar columnas disponibles
   - Validar tipos de datos
   - Detectar valores nulos
   - Identificar alcaldías cubiertas
   - Analizar rangos de intensidad

2. **Sitios de Encharcamiento**
   - Validar CRS (debe ser EPSG:4326 o transformable)
   - Verificar geometrías válidas
   - Contar puntos por alcaldía
   - Detectar duplicados espaciales
   - Analizar atributos disponibles

3. **Viviendas por AGEB**
   - Validar CRS
   - Verificar geometrías de polígonos
   - Analizar variables demográficas
   - Identificar AGEBs de CDMX
   - Detectar datos faltantes

**Entregables FASE 1:**
- ✅ Script de auditoría
- [ ] `data/audit_reports/data_audit_report_YYYYMMDD_HHMMSS.json`
- [ ] `data/audit_reports/executive_summary_YYYYMMDD_HHMMSS.txt`

---

### FASE 2: LIMPIEZA PROFESIONAL

**Objetivo:** Corregir problemas detectados y estandarizar datos

**Decisiones de Limpieza:**

1. **Corrección de Geometrías**
   - Reparar geometrías inválidas con `buffer(0)`
   - Eliminar geometrías nulas (documentar cantidad)
   - Simplificar geometrías complejas si es necesario

2. **Estandarización de CRS**
   - Transformar todos los datasets a EPSG:4326 (WGS84)
   - Justificación: Estándar internacional, compatible con web mapping

3. **Manejo de Valores Nulos**
   - Numéricos: Imputar con mediana por alcaldía
   - Categóricos: Imputar con moda o "Desconocido"
   - Documentar todas las imputaciones

4. **Eliminación de Duplicados**
   - Registros exactamente duplicados: eliminar
   - Duplicados espaciales (< 10m): consolidar

5. **Estandarización de Nombres**
   - Columnas: snake_case
   - Alcaldías: Normalizar acentos y mayúsculas
   - Crear diccionario de mapeo

**Script:** `scripts/02_data_cleaning.py`

**Entregables FASE 2:**
- Datasets limpios en `data/cleaned/`
- Reporte de transformaciones
- Diccionario de mapeo de nombres

---

### FASE 3: INGENIERÍA DE CARACTERÍSTICAS

**Objetivo:** Crear variables predictivas para riesgo de inundación

**Variables a Generar:**

#### Del Atlas de Precipitación:
- `riesgo_precipitacion` (categórico: Muy Bajo, Bajo, Medio, Alto, Muy Alto)
- `intensidad_lluvia_mm_h` (numérico)
- `periodo_retorno_anos` (numérico)

#### De Sitios de Encharcamiento:
- `encharcamiento_historico` (binario: 0/1)
- `distancia_encharcamiento_m` (numérico: distancia al punto más cercano)
- `densidad_encharcamientos_1km` (numérico: count en radio de 1km)
- `recurrencia_encharcamiento` (categórico si disponible)

#### De Viviendas AGEB:
- `poblacion_total` (numérico)
- `densidad_poblacional_hab_km2` (numérico)
- `viviendas_totales` (numérico)
- `viviendas_con_drenaje_pct` (numérico)
- `viviendas_con_agua_pct` (numérico)
- `indice_marginacion` (numérico si disponible)

#### Variables Derivadas:
- `riesgo_combinado` = f(precipitación, encharcamiento, densidad)
- `vulnerabilidad_infraestructura` = f(drenaje, agua, viviendas)
- `exposicion_poblacional` = f(población, densidad, riesgo)

**Script:** `scripts/03_feature_engineering.py`

**Entregables FASE 3:**
- Dataset con features en `data/features/`
- Diccionario de features con descripciones
- Análisis de correlaciones

---

### FASE 4: INTEGRACIÓN ESPACIAL

**Objetivo:** Consolidar todos los datasets en uno solo mediante Spatial Joins

**Estrategia de Integración:**

1. **Base Espacial:** Grid de CDMX o AGEBs
   - Crear grid regular de 500m x 500m sobre CDMX
   - O usar AGEBs como unidades espaciales base

2. **Spatial Joins:**
   ```
   Base Grid/AGEB
   ├─ JOIN precipitación (spatial join nearest)
   ├─ JOIN encharcamientos (spatial join within + buffer)
   ├─ JOIN viviendas (spatial join intersects)
   └─ JOIN alcaldías (spatial join within)
   ```

3. **Agregaciones:**
   - Por grid/AGEB: mean, sum, count según variable
   - Mantener información geográfica (lat, lon, geometry)

4. **Validación:**
   - Verificar cobertura completa de CDMX
   - Detectar zonas sin datos
   - Validar consistencia espacial

**Script:** `scripts/04_spatial_integration.py`

**Entregables FASE 4:**
- Dataset consolidado: `data/processed/cdmx_flood_risk_integrated.gpkg`
- Dataset tabular: `data/processed/cdmx_flood_risk_integrated.csv`
- Mapa de cobertura de datos
- Reporte de integración

---

### FASE 5: MODELADO PREDICTIVO

**Objetivo:** Entrenar modelo robusto para predecir riesgo de inundación

**Variable Objetivo:**
- `flood_risk_level` (categórico: 0=Muy Bajo, 1=Bajo, 2=Medio, 3=Alto, 4=Muy Alto)
- O `flood_probability` (numérico: 0-1)

**Features Predictoras:**
- Todas las variables generadas en FASE 3
- Selección automática de features importantes

**Modelos a Comparar:**

1. **Random Forest** (baseline)
   - n_estimators: 100, 200, 500
   - max_depth: 10, 20, None
   - min_samples_split: 2, 5, 10

2. **XGBoost**
   - learning_rate: 0.01, 0.1, 0.3
   - max_depth: 3, 6, 9
   - n_estimators: 100, 200, 500

3. **LightGBM**
   - learning_rate: 0.01, 0.1
   - num_leaves: 31, 63, 127
   - n_estimators: 100, 200, 500

4. **Gradient Boosting** (scikit-learn)
   - Similar a XGBoost

**Estrategia de Validación:**
- Train/Test Split: 80/20
- Cross-Validation: 5-fold
- Stratified sampling para clases balanceadas

**Métricas de Evaluación:**
- Accuracy
- Precision (por clase)
- Recall (por clase)
- F1-Score (macro y weighted)
- ROC-AUC (si es clasificación binaria)
- Confusion Matrix

**Selección del Mejor Modelo:**
- Priorizar F1-Score weighted
- Considerar interpretabilidad
- Evaluar tiempo de inferencia

**Script:** `scripts/05_model_training.py`

**Entregables FASE 5:**
- Modelo entrenado: `models/flood_risk_model_best.pkl`
- Scaler: `models/scaler.pkl`
- Metadata: `models/model_metadata.json`
- Reporte de métricas: `models/evaluation_report.json`
- Gráficas de evaluación

---

### FASE 6: EXPLICABILIDAD

**Objetivo:** Hacer el modelo interpretable para usuarios no técnicos

**Técnicas a Implementar:**

1. **Feature Importance**
   - Importancia global de cada variable
   - Visualización de top 20 features

2. **SHAP Values**
   - SHAP summary plot
   - SHAP dependence plots
   - SHAP force plots para predicciones individuales

3. **Explicaciones en Lenguaje Natural**
   - Template: "El riesgo es {nivel} porque {razones principales}"
   - Ejemplo: "El riesgo es ALTO porque:
     - Alta intensidad de precipitación (85 mm/h)
     - Zona con historial de encharcamientos (3 eventos)
     - Baja cobertura de drenaje (45%)"

**Script:** `scripts/06_explainability.py`

**Entregables FASE 6:**
- Módulo de explicabilidad: `app/services/explainer_v2.py`
- Visualizaciones SHAP
- Templates de explicaciones

---

### FASE 7: INTEGRACIÓN CON FLOODMIRROR AI

**Objetivo:** Actualizar backend y frontend sin romper funcionalidad

**Cambios en Backend:**

1. **Data Loader** (`app/utils/data_loader.py`)
   - Agregar método `load_integrated_data()`
   - Mantener compatibilidad con API actual

2. **Model** (`app/ml/model.py`)
   - Actualizar para usar nuevo modelo
   - Mantener interfaz de predicción existente

3. **Schemas** (`app/models/schemas.py`)
   - Agregar nuevos campos si es necesario
   - Mantener retrocompatibilidad

4. **Endpoints** (`app/main.py`)
   - Agregar endpoint `/predict/v2` con nuevo modelo
   - Mantener `/predict` con modelo anterior

**Cambios en Frontend:**
- Actualizar visualizaciones con nuevas variables
- Agregar explicaciones SHAP
- Mejorar mapas con datos reales

**Testing:**
- Probar todos los endpoints
- Validar respuestas
- Verificar tiempos de respuesta

**Scripts:**
- `scripts/07_backend_integration.py`
- `scripts/08_test_integration.py`

**Entregables FASE 7:**
- Backend actualizado
- Tests pasando
- Documentación de cambios

---

### FASE 8: ENTREGABLES FINALES

**Documentación:**

1. **Reporte Técnico Completo**
   - Metodología
   - Decisiones tomadas
   - Resultados
   - Limitaciones

2. **Diccionario de Datos**
   - Todas las variables
   - Fuentes
   - Transformaciones

3. **Manual de Usuario**
   - Cómo usar la API
   - Interpretación de resultados

4. **Guía de Mantenimiento**
   - Cómo actualizar datos
   - Cómo reentrenar modelo

**Datasets Finales:**
- `data/final/cdmx_flood_risk_dataset.csv`
- `data/final/cdmx_flood_risk_dataset.gpkg`
- `data/final/training_dataset.csv`

**Modelos:**
- `models/flood_risk_model_production.pkl`
- `models/scaler_production.pkl`
- `models/feature_names.json`

**Reportes:**
- `reports/data_quality_report.pdf`
- `reports/model_evaluation_report.pdf`
- `reports/technical_documentation.pdf`

---

## 📋 CHECKLIST DE CALIDAD

### Datos
- [ ] Todos los datasets auditados
- [ ] Geometrías válidas
- [ ] CRS estandarizado (EPSG:4326)
- [ ] Sin duplicados
- [ ] Valores nulos manejados
- [ ] Nombres estandarizados

### Features
- [ ] Variables documentadas
- [ ] Correlaciones analizadas
- [ ] Outliers identificados
- [ ] Escalado apropiado

### Modelo
- [ ] Múltiples modelos comparados
- [ ] Mejor modelo seleccionado con justificación
- [ ] Métricas > 80% accuracy
- [ ] Explicabilidad implementada
- [ ] Tiempo de inferencia < 1s

### Integración
- [ ] API funcionando
- [ ] Tests pasando
- [ ] Documentación actualizada
- [ ] Sin breaking changes

### Entregables
- [ ] Todos los archivos generados
- [ ] Documentación completa
- [ ] Código comentado
- [ ] README actualizado

---

## 🚀 PRÓXIMOS PASOS INMEDIATOS

1. ✅ Instalar dependencias (`pip install -r requirements.txt`)
2. ⏳ Ejecutar auditoría de datos (`python scripts/01_data_audit.py`)
3. ⏳ Revisar reporte de auditoría
4. ⏳ Proceder con limpieza según problemas detectados

---

## 📞 CONTACTO Y SOPORTE

Para preguntas o problemas durante la implementación, documentar en:
- Issues del proyecto
- Comentarios en código
- Logs de ejecución

---

**Última actualización:** 2026-06-06  
**Versión del plan:** 1.0