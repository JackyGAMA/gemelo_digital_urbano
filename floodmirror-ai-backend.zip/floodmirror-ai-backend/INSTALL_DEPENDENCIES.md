# Instalación de Dependencias - FloodMirror AI

## Dependencias Agregadas para Análisis Geoespacial y ML Avanzado

### Librerías Geoespaciales (FASE 1-4)
```
geopandas==0.14.1      # Análisis de datos geoespaciales
shapely==2.0.2         # Manipulación de geometrías
pyproj==3.6.1          # Transformaciones de CRS
fiona==1.9.5           # Lectura/escritura de Shapefiles
```

### Librerías ML Avanzadas (FASE 5-6)
```
xgboost==2.0.3         # Gradient Boosting optimizado
lightgbm==4.1.0        # Light Gradient Boosting Machine
shap==0.44.0           # Explicabilidad de modelos
matplotlib==3.8.2      # Visualizaciones
seaborn==0.13.0        # Visualizaciones estadísticas
```

## Instalación

### Windows (PowerShell)
```powershell
cd floodmirror-ai-backend
pip install -r requirements.txt
```

### Linux/Mac
```bash
cd floodmirror-ai-backend
pip install -r requirements.txt
```

## Verificación de Instalación

```python
# Verificar instalación de librerías geoespaciales
import geopandas as gpd
import shapely
import pyproj
print("✅ Librerías geoespaciales instaladas correctamente")

# Verificar instalación de librerías ML
import xgboost
import lightgbm
import shap
print("✅ Librerías ML avanzadas instaladas correctamente")
```

## Notas Importantes

1. **GeoPandas** requiere GDAL, que se instala automáticamente con Fiona
2. **SHAP** puede tardar en instalarse debido a sus dependencias
3. Si hay problemas con GDAL en Windows, considerar usar conda:
   ```
   conda install -c conda-forge geopandas
   ```

## Troubleshooting

### Error: "Microsoft Visual C++ 14.0 is required"
- Instalar [Microsoft C++ Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/)

### Error con GDAL en Windows
- Usar conda en lugar de pip para librerías geoespaciales
- O descargar wheels precompilados de [Christoph Gohlke](https://www.lfd.uci.edu/~gohlke/pythonlibs/)

### Error con Fiona
- Asegurarse de tener las últimas actualizaciones de pip:
  ```
  pip install --upgrade pip setuptools wheel