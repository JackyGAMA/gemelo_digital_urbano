"""
Configuration file for FloodMirror AI
Centralized configuration management
"""
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """
    Application settings
    Can be overridden by environment variables
    """
    
    # API Settings
    API_TITLE: str = "FloodMirror AI API"
    API_VERSION: str = "1.0.0"
    API_DESCRIPTION: str = "API para predicción de riesgo de inundación urbana con módulo Mirror"
    
    # Server Settings
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    RELOAD: bool = False
    
    # CORS Settings
    CORS_ORIGINS: list = ["*"]
    CORS_CREDENTIALS: bool = True
    CORS_METHODS: list = ["*"]
    CORS_HEADERS: list = ["*"]
    
    # Data Settings
    DATA_DIR: str = "data"
    FLOOD_DATA_FILE: str = "flood_clean.csv"
    CDMX_DATA_FILE: str = "cdmx_clean.csv"
    
    # Model Settings
    MODEL_DIR: str = "models"
    MODEL_FILE: str = "flood_model.pkl"
    SCALER_FILE: str = "scaler.pkl"
    METADATA_FILE: str = "model_metadata.pkl"
    
    # ML Model Parameters
    N_ESTIMATORS: int = 100
    MAX_DEPTH: int = 10
    MIN_SAMPLES_SPLIT: int = 5
    MIN_SAMPLES_LEAF: int = 2
    RANDOM_STATE: int = 42
    TEST_SIZE: float = 0.2
    
    # Mirror Module Settings
    MIRROR_KNN_NEIGHBORS: int = 5
    MIRROR_DEFAULT_METHOD: str = "auto"
    
    # Confidence Calculation Weights
    CONFIDENCE_WEIGHT_DATA: float = 0.35
    CONFIDENCE_WEIGHT_MODEL: float = 0.40
    CONFIDENCE_WEIGHT_MIRROR: float = 0.25
    
    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # Feature Names (for validation)
    REQUIRED_FLOOD_FEATURES: list = [
        "MonsoonIntensity",
        "TopographyDrainage",
        "RiverManagement",
        "Deforestation",
        "Urbanization",
        "DrainageSystems",
        "PopulationScore",
        "Watersheds"
    ]
    
    CDMX_FEATURES: list = [
        "alcaldia",
        "intensidad",
        "int2",
        "area_m2",
        "period_ret",
        "latitud",
        "longitud"
    ]
    
    # Risk Level Thresholds
    RISK_THRESHOLD_VERY_LOW: float = 0.2
    RISK_THRESHOLD_LOW: float = 0.4
    RISK_THRESHOLD_MODERATE: float = 0.6
    RISK_THRESHOLD_HIGH: float = 0.8
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


# Create global settings instance
settings = Settings()

# Made with Bob
