# -*- coding: utf-8 -*-
import requests
import json
import sys
import io

# Fix encoding for Windows
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

url = "http://localhost:8000/predict/v2"
data = {
    "alcaldia": "Iztapalapa",
    "intensidad": 65,
    "period_ret": 10,
    "area_m2": 5000,
    "latitud": 19.3573,
    "longitud": -99.0554
}

response = requests.post(url, json=data)
result = response.json()

# Save to file
with open('response.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2, ensure_ascii=False)

print("Response saved to response.json")
print("\nKey fields:")
print(f"  risk_level: {result.get('risk_level')}")
print(f"  flood_probability: {result.get('flood_probability')}")
print(f"  alert_level in location_info: {result.get('location_info', {}).get('alert_level')}")

# Made with Bob
