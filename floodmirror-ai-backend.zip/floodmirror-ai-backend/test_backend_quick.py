# -*- coding: utf-8 -*-
"""
Quick test to verify backend is working
"""
import requests
import json
import sys

# Fix encoding for Windows
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# Test endpoint
url = "http://localhost:8000/predict/v2"

# Test data for different alcaldias
test_cases = [
    {
        "name": "Iztapalapa",
        "data": {
            "alcaldia": "Iztapalapa",
            "intensidad": 65,
            "period_ret": 10,
            "area_m2": 5000,
            "latitud": 19.3573,
            "longitud": -99.0554
        }
    },
    {
        "name": "Xochimilco",
        "data": {
            "alcaldia": "Xochimilco",
            "intensidad": 70,
            "period_ret": 25,
            "area_m2": 8000,
            "latitud": 19.2577,
            "longitud": -99.1036
        }
    },
    {
        "name": "Cuauhtemoc",
        "data": {
            "alcaldia": "Cuauhtemoc",
            "intensidad": 55,
            "period_ret": 5,
            "area_m2": 3000,
            "latitud": 19.4326,
            "longitud": -99.1332
        }
    }
]

print("Testing FloodMirror AI Backend\n")
print("=" * 60)

for test in test_cases:
    print(f"\nTesting: {test['name']}")
    print("-" * 60)
    
    try:
        response = requests.post(url, json=test['data'], timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            print(f"[OK] Status: SUCCESS")
            print(f"   Risk Level: {result['risk_level']}")
            print(f"   Flood Probability: {result['flood_probability']:.2%}")
            print(f"   Confidence: {result['confidence']['overall_confidence']:.2%}")
            
            # Check weather info
            weather_info = result.get('location_info', {}).get('weather_info', {})
            if weather_info.get('status') == 'available':
                print(f"   [WEATHER] {weather_info.get('description', 'N/A')}")
                print(f"   Rain: {weather_info.get('current_rain', 0)} mm/h")
                print(f"   Rain Probability: {weather_info.get('rain_probability', 0)}%")
            else:
                print(f"   [WARNING] Weather: {weather_info.get('description', 'Not available')}")
            
            # Check alert - it's in location_info
            location_info = result.get('location_info', {})
            alert_level = location_info.get('alert_level', 'N/A')
            print(f"   [ALERT] Level: {alert_level.upper()}")
            
            # Show explanation
            explanation = result.get('explanation', {})
            interpretation = explanation.get('interpretation', '')
            if interpretation:
                print(f"   [INFO] {interpretation[:100]}...")
            
        else:
            print(f"[ERROR] Status: FAILED ({response.status_code})")
            print(f"   Error: {response.text}")
            
    except requests.exceptions.ConnectionError:
        print(f"[ERROR] Connection Error: Backend not running at {url}")
        print(f"   Start backend with: uvicorn app.main:app --reload")
        break
    except Exception as e:
        print(f"[ERROR] {e}")

print("\n" + "=" * 60)
print("[OK] Test completed")

# Made with Bob
